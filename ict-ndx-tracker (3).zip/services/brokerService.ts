
import { Position, OrderResponse } from '../types';

// Simulation of a Broker API (e.g., Pepperstone cTrader API or FIX API)
class BrokerService {
  private isConnected: boolean = false;
  private positions: Position[] = [];

  async connect(apiKey: string): Promise<boolean> {
    // Simulate API connection delay
    return new Promise((resolve) => {
      setTimeout(() => {
        this.isConnected = true;
        console.log(`Connected to Pepperstone Broker API with key: ${apiKey.substring(0, 4)}...`);
        resolve(true);
      }, 1000);
    });
  }

  async placeOrder(
    symbol: string, 
    side: 'Buy' | 'Sell', 
    size: number, 
    currentPrice: number,
    tp?: number,
    sl?: number
  ): Promise<OrderResponse> {
    if (!this.isConnected) {
      return { success: false, message: "Broker not connected." };
    }

    // Simulate slippage
    const slippage = 0.02; // points
    const executionPrice = side === 'Buy' ? currentPrice + slippage : currentPrice - slippage;

    const newPosition: Position = {
      id: Math.random().toString(36).substring(7),
      symbol,
      side,
      entryPrice: executionPrice,
      size,
      openTime: Date.now(),
      pnl: 0,
      tp,
      sl
    };

    this.positions.push(newPosition);

    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, position: newPosition });
      }, 500); // Simulate network latency
    });
  }

  async modifyPosition(id: string, newTp?: number | null, newSl?: number | null): Promise<boolean> {
      const pos = this.positions.find(p => p.id === id);
      if (!pos) return false;
      
      // Update values if provided (null means remove, undefined means no change)
      if (newTp !== undefined) pos.tp = newTp === null ? undefined : newTp;
      if (newSl !== undefined) pos.sl = newSl === null ? undefined : newSl;
      
      return true;
  }

  async closePosition(positionId: string, closingPrice: number): Promise<number> {
    const posIndex = this.positions.findIndex(p => p.id === positionId);
    if (posIndex === -1) return 0;

    const pos = this.positions[posIndex];
    // Calculate PnL: (Closing - Entry) * Size * ContractMultiplier
    // Simplified for NDX: 1 point = $20 per lot (standard contract example)
    const multiplier = 20; 
    let pnl = 0;
    
    if (pos.side === 'Buy') {
      pnl = (closingPrice - pos.entryPrice) * pos.size * multiplier;
    } else {
      pnl = (pos.entryPrice - closingPrice) * pos.size * multiplier;
    }

    this.positions.splice(posIndex, 1);
    return pnl;
  }

  calculateFloatingPnL(position: Position, currentPrice: number): number {
    const multiplier = 20; // Example NDX contract multiplier
    if (position.side === 'Buy') {
      return (currentPrice - position.entryPrice) * position.size * multiplier;
    } else {
      return (position.entryPrice - currentPrice) * position.size * multiplier;
    }
  }
}

export const brokerService = new BrokerService();
