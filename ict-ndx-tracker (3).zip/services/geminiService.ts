
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { MarketNarrative, ChartAnalysisResult } from '../types';

const getAiClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const fetchMarketNarrative = async (): Promise<MarketNarrative> => {
  const ai = getAiClient();
  
  const prompt = `
    Conduct a specialized ICT (Inner Circle Trader) analysis of the current market sentiment for Nasdaq 100 (NDX/US100).
    
    Use Google Search to find:
    1. Today's key economic news events (Red Folder news).
    2. Current price action context (Bullish/Bearish).
    3. Key liquidity levels (Previous Daily High/Low).
    
    Output strictly in JSON format (without markdown code blocks) with the following structure:
    {
      "sentiment": "Bullish" | "Bearish" | "Neutral",
      "summary": "A short paragraph describing the Daily Bias.",
      "keyLevels": ["Level 1", "Level 2"],
      "newsEvents": ["Event 1", "Event 2"]
    }
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "{}";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const jsonString = jsonMatch ? jsonMatch[0] : "{}";
    
    const parsed = JSON.parse(jsonString);

    const urls = groundingChunks
      .map((chunk: any) => chunk.web?.uri)
      .filter((uri: string | undefined): uri is string => !!uri);

    return {
      sentiment: parsed.sentiment || 'Neutral',
      summary: parsed.summary || 'Unable to fetch summary.',
      keyLevels: parsed.keyLevels || [],
      newsEvents: parsed.newsEvents || [],
      groundingUrls: urls
    };

  } catch (error) {
    console.error("Error fetching market narrative:", error);
    throw new Error("Failed to fetch market narrative. Please try again.");
  }
};

export const analyzeChartImage = async (base64Image: string): Promise<ChartAnalysisResult> => {
  const ai = getAiClient();

  const prompt = `
    You are an expert ICT (Inner Circle Trader) mentor. Analyze this chart image.
    
    Identify:
    1. Overall Trend (Bullish, Bearish, or Neutral).
    2. Market Structure Points visible (e.g., Higher High (HH), Higher Low (HL), Lower High (LH), Lower Low (LL)).
    3. ICT Concepts present: Fair Value Gaps (FVG), Order Blocks (OB), Liquidity Sweeps, Breakers, MSS.
    
    Identify potential trade setups from the visible candles:
    - If a clear setup exists, provide a suggested entry and exit price level based on the current price scale.
    
    Output strictly in JSON format with this schema:
    {
      "analysis": "string (Concise actionable analysis)",
      "trend": "Bullish" | "Bearish" | "Neutral",
      "structurePoints": ["HH", "HL", "LH", "LL"],
      "detectedConcepts": ["FVG", "Order Block", "Liquidity", "Breaker"],
      "suggestedEntry": number (optional, identifiable entry price),
      "suggestedExit": number (optional, identifiable target/exit price)
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png',
              data: base64Image
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text || "{}";
    let parsed: any = {};
    
    try {
      parsed = JSON.parse(text);
    } catch (e) {
      console.warn("JSON parse failed, falling back to raw text", e);
      parsed = {
        analysis: text,
        trend: 'Unknown',
        structurePoints: [],
        detectedConcepts: []
      };
      
      if (text.includes("FVG") || text.toLowerCase().includes("fair value gap")) parsed.detectedConcepts.push("FVG");
      if (text.includes("Order Block") || text.toLowerCase().includes("order block")) parsed.detectedConcepts.push("Order Block");
      if (text.toLowerCase().includes("liquidity")) parsed.detectedConcepts.push("Liquidity");
    }

    return {
      analysis: parsed.analysis || text,
      detectedConcepts: parsed.detectedConcepts || [],
      marketStructure: {
        trend: parsed.trend || 'Unknown',
        points: parsed.structurePoints || []
      },
      suggestedEntry: parsed.suggestedEntry,
      suggestedExit: parsed.suggestedExit
    };

  } catch (error) {
    console.error("Error analyzing chart:", error);
    throw new Error("Failed to analyze chart.");
  }
};

export const generateIctImage = async (prompt: string, size: '1K' | '2K' | '4K'): Promise<string> => {
  const ai = getAiClient();

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [
          {
            text: `Create a high-quality, professional trading-themed illustration. ${prompt}. Style: Modern, clean, financial terminal aesthetic, dark mode colors (emerald green, deep blues, charcoal).`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
          imageSize: size
        }
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data returned from model");
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error("Failed to generate image.");
  }
};
