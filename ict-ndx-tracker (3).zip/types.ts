
export interface ICTSession {
  name: string;
  startLocal: string; // HH:mm format
  endLocal: string; // HH:mm format
  description: string;
  type: 'London' | 'NewYork' | 'Asian' | 'Close';
}

export enum ICTConcept {
  FVG = 'Fair Value Gap',
  OB = 'Order Block',
  Breaker = 'Breaker Block',
  LiquiditySweep = 'Liquidity Sweep',
  MSS = 'Market Structure Shift',
  OTE = 'Optimal Trade Entry'
}

export interface TradeEntry {
  id: string;
  date: string;
  pair: string;
  direction: 'Long' | 'Short';
  entryPrice: number;
  exitPrice: number;
  result: 'Win' | 'Loss' | 'BE';
  concepts: ICTConcept[];
  notes: string;
}

export interface MarketNarrative {
  sentiment: 'Bullish' | 'Bearish' | 'Neutral';
  summary: string;
  keyLevels: string[];
  newsEvents: string[];
  groundingUrls: string[];
}

export interface ChartAnalysisResult {
  analysis: string;
  detectedConcepts: string[];
  marketStructure?: {
    trend: 'Bullish' | 'Bearish' | 'Neutral' | 'Unknown';
    points: string[];
  };
  suggestedEntry?: number;
  suggestedExit?: number;
}

export interface Position {
  id: string;
  symbol: string;
  side: 'Buy' | 'Sell';
  entryPrice: number;
  size: number; // Lots
  openTime: number;
  pnl?: number;
  tp?: number; // Take Profit
  sl?: number; // Stop Loss
}

export interface OrderResponse {
  success: boolean;
  position?: Position;
  message?: string;
}
