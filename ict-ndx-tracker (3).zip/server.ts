import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- M-Pesa Integration ---
  app.post('/api/payments/mpesa/register-urls', async (req, res) => {
    try {
      // 1. Get Access Token
      const auth = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64');
      const tokenResponse = await axios.get('https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials', {
        headers: { Authorization: `Basic ${auth}` }
      });
      const accessToken = tokenResponse.data.access_token;

      // 2. Register URLs
      const registerResponse = await axios.post('https://sandbox.safaricom.co.ke/mpesa/c2b/v1/registerurl', {
        ShortCode: process.env.MPESA_SHORTCODE,
        ResponseType: 'Completed',
        ConfirmationURL: `${process.env.APP_URL}/api/payments/mpesa/confirmation`,
        ValidationURL: `${process.env.APP_URL}/api/payments/mpesa/validation`
      }, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      res.json(registerResponse.data);
    } catch (error: any) {
      console.error('M-Pesa URL Registration Error:', error.response?.data || error.message);
      res.status(500).json({ error: 'M-Pesa URL registration failed', details: error.response?.data });
    }
  });

  app.post('/api/payments/mpesa/confirmation', (req, res) => {
    console.log('M-Pesa Confirmation Received:', req.body);
    res.json({ ResultCode: 0, ResultDesc: 'Success' });
  });

  app.post('/api/payments/mpesa/validation', (req, res) => {
    console.log('M-Pesa Validation Received:', req.body);
    res.json({ ResultCode: 0, ResultDesc: 'Success' });
  });

  app.post('/api/payments/mpesa', async (req, res) => {
    const { phoneNumber, amount } = req.body;
    
    try {
      // 1. Get Access Token
      const auth = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64');
      const tokenResponse = await axios.get('https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials', {
        headers: { Authorization: `Basic ${auth}` }
      });
      const accessToken = tokenResponse.data.access_token;

      // 2. Trigger STK Push Request
      const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14);
      const password = Buffer.from(`${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${timestamp}`).toString('base64');

      const stkResponse = await axios.post('https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest', {
        BusinessShortCode: process.env.MPESA_SHORTCODE,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: amount,
        PartyA: phoneNumber,
        PartyB: process.env.MPESA_SHORTCODE,
        PhoneNumber: phoneNumber,
        CallBackURL: process.env.MPESA_CALLBACK_URL,
        AccountReference: 'TeCryptoNDX',
        TransactionDesc: 'Subscription Payment'
      }, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      res.json(stkResponse.data);
    } catch (error: any) {
      console.error('M-Pesa Error:', error.response?.data || error.message);
      res.status(500).json({ error: 'M-Pesa payment failed', details: error.response?.data });
    }
  });

  // --- Crypto Integration (Bybit) ---
  app.post('/api/payments/crypto', async (req, res) => {
    const { amount, currency = 'USD' } = req.body;

    try {
      const apiKey = process.env.BYBIT_API_KEY;
      const apiSecret = process.env.BYBIT_API_SECRET;
      
      // In a real Bybit integration, you would sign the request with the secret.
      // For now, we'll simulate a successful initiation.
      console.log(`Initiating Bybit payment with API Key: ${apiKey?.slice(0, 4)}... and Secret: ${apiSecret?.slice(0, 4)}...`);
      
      // Simulate a hosted payment URL or deposit address generation
      res.json({ 
        success: true,
        message: 'Bybit payment initiated',
        hosted_url: 'https://www.bybit.com/en-US/fiat/purchase/crypto',
        amount,
        currency
      });
    } catch (error: any) {
      console.error('Crypto Error:', error.message);
      res.status(500).json({ error: 'Crypto payment creation failed' });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
