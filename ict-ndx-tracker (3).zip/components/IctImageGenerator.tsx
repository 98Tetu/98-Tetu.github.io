import React, { useState, useEffect } from 'react';
import { generateIctImage } from '../services/geminiService';
import { Image as ImageIcon, Loader2, Download, Sparkles, Wand2, Key, AlertCircle, ExternalLink, Star } from 'lucide-react';
import Pricing from './Pricing';

declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

interface IctImageGeneratorProps {
  isPremium?: boolean;
}

const IctImageGenerator: React.FC<IctImageGeneratorProps> = ({ isPremium }) => {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState<boolean | null>(null);
  const [isPricingOpen, setIsPricingOpen] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      } else {
        setHasKey(true); // Fallback for environments without aistudio global
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setHasKey(true); // Assume success per guidelines
    }
  };

  const handleGenerate = async () => {
    if (!prompt) return;
    setLoading(true);
    setError(null);
    try {
      const imageUrl = await generateIctImage(prompt, size);
      setGeneratedImage(imageUrl);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to generate image";
      setError(msg);
      
      // If permission denied, prompt to re-select key
      if (msg.includes("PERMISSION_DENIED") || msg.includes("403")) {
        setHasKey(false);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = `ict-analysis-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          ICT Concept Visualizer
        </h2>
      </div>

      <div className="space-y-4 relative">
        {!isPremium && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md rounded-xl border border-white/10 p-6 text-center">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
              <Star className="w-8 h-8 text-primary fill-primary" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Premium Feature</h3>
            <p className="text-sm text-zinc-400 max-w-xs mb-6">
              Visualizing ICT concepts with AI is a premium feature. Upgrade to Tecrypto Elite to unlock.
            </p>
            <button 
              onClick={() => setIsPricingOpen(true)}
              className="px-8 py-3 bg-primary hover:bg-emerald-600 text-white font-bold rounded-xl transition-all shadow-lg shadow-primary/20 active:scale-95"
            >
              Unlock Now
            </button>
            <Pricing isOpen={isPricingOpen} onClose={() => setIsPricingOpen(false)} />
          </div>
        )}

        {hasKey === false ? (
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-6 text-center space-y-4">
            <div className="w-12 h-12 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto">
              <Key className="w-6 h-6 text-amber-500" />
            </div>
            <div>
              <h3 className="text-white font-bold mb-1">API Key Required</h3>
              <p className="text-xs text-gray-400 max-w-xs mx-auto leading-relaxed">
                High-quality image generation requires a paid Gemini API key. Please select a key from a project with billing enabled.
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <button
                onClick={handleSelectKey}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Key className="w-4 h-4" />
                Select API Key
              </button>
              <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[10px] text-gray-500 hover:text-amber-500 flex items-center justify-center gap-1 transition-colors"
              >
                Learn about Gemini API billing <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        ) : (
          <>
            <div>
              <label className="block text-xs text-gray-500 mb-2 uppercase font-bold">Describe the Concept</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., A bearish Fair Value Gap on the 15m timeframe being filled before a displacement lower..."
                className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 text-sm text-white focus:border-amber-500 outline-none h-24 resize-none"
              />
            </div>

            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 uppercase font-bold">Resolution:</span>
                <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
                  {(['1K', '2K', '4K'] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={`px-3 py-1 text-xs font-bold rounded transition-all ${
                        size === s ? 'bg-amber-500 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={handleGenerate}
                disabled={loading || !prompt}
                className="px-6 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-bold rounded-lg shadow-lg flex items-center gap-2 transition-transform active:scale-95"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Wand2 className="w-4 h-4" /> Generate</>}
              </button>
            </div>
          </>
        )}

        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {generatedImage ? (
          <div className="relative mt-6 rounded-xl overflow-hidden border border-white/10 group">
            <img src={generatedImage} alt="Generated ICT Concept" className="w-full h-auto" />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
              <button
                onClick={handleDownload}
                className="p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
                title="Download Image"
              >
                <Download className="w-6 h-6" />
              </button>
              <button
                onClick={() => setGeneratedImage(null)}
                className="p-3 bg-red-500/20 hover:bg-red-500/40 rounded-full text-red-500 transition-colors"
                title="Clear"
              >
                <ImageIcon className="w-6 h-6" />
              </button>
            </div>
          </div>
        ) : (
          !loading && (
            <div className="mt-6 border-2 border-dashed border-white/5 rounded-xl p-12 flex flex-col items-center justify-center text-gray-600">
              <ImageIcon className="w-12 h-12 mb-4 opacity-20" />
              <p className="text-sm italic">Generated visuals will appear here</p>
            </div>
          )
        )}
      </div>
    </div>
  );
};

export default IctImageGenerator;
