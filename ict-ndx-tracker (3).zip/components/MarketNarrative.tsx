import React, { useState, useEffect } from 'react';
import { fetchMarketNarrative } from '../services/geminiService';
import { MarketNarrative as MarketNarrativeType } from '../types';
import { Newspaper, TrendingUp, TrendingDown, Minus, RefreshCw, ExternalLink, AlertTriangle } from 'lucide-react';

const MarketNarrative: React.FC = () => {
  const [data, setData] = useState<MarketNarrativeType | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchMarketNarrative();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Initial load
    // loadData(); // Auto-load can cost tokens, let's make it manual or once per session
  }, []);

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'Bullish': return <TrendingUp className="w-6 h-6 text-green-500" />;
      case 'Bearish': return <TrendingDown className="w-6 h-6 text-red-500" />;
      default: return <Minus className="w-6 h-6 text-gray-500" />;
    }
  };

  return (
    <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-lg h-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Newspaper className="w-5 h-5 text-secondary" />
          Daily Bias & Narrative
        </h2>
        <button
          onClick={loadData}
          disabled={loading}
          className="p-2 rounded-full hover:bg-white/10 transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-5 h-5 text-gray-400 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {!data && !loading && !error && (
        <div className="text-center py-10 text-gray-500">
          <p>Click refresh to generate today's ICT market narrative using Gemini.</p>
        </div>
      )}

      {loading && (
        <div className="flex flex-col items-center justify-center py-10 space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="text-sm text-gray-400 animate-pulse">Scanning news and price action...</p>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {data && !loading && (
        <div className="space-y-6">
          <div className="flex items-center gap-4 p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="p-3 bg-white/5 rounded-full">
              {getSentimentIcon(data.sentiment)}
            </div>
            <div>
              <div className="text-sm text-gray-400 uppercase tracking-wider font-semibold">Overall Sentiment</div>
              <div className="text-xl font-bold text-white">{data.sentiment}</div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-300 mb-2">Narrative Summary</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              {data.summary}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-xs font-semibold text-secondary uppercase tracking-wider mb-2">Red Folder Events</h3>
              <ul className="space-y-2">
                {data.newsEvents.length > 0 ? (
                  data.newsEvents.map((event, i) => (
                    <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0"></span>
                      {event}
                    </li>
                  ))
                ) : (
                  <li className="text-sm text-gray-500 italic">No major events detected.</li>
                )}
              </ul>
            </div>
            <div>
              <h3 className="text-xs font-semibold text-primary uppercase tracking-wider mb-2">Key Levels (PD Arrays)</h3>
              <ul className="space-y-2">
                {data.keyLevels.length > 0 ? (
                  data.keyLevels.map((level, i) => (
                    <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0"></span>
                      {level}
                    </li>
                  ))
                ) : (
                  <li className="text-sm text-gray-500 italic">No levels identified.</li>
                )}
              </ul>
            </div>
          </div>

          {data.groundingUrls.length > 0 && (
             <div className="pt-4 border-t border-white/10">
               <h4 className="text-xs text-gray-500 mb-2">Sources</h4>
               <div className="flex flex-wrap gap-2">
                 {data.groundingUrls.slice(0, 3).map((url, i) => (
                   <a 
                    key={i} 
                    href={url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-xs text-secondary hover:underline bg-secondary/10 px-2 py-1 rounded"
                   >
                     Source {i + 1} <ExternalLink className="w-3 h-3" />
                   </a>
                 ))}
               </div>
             </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MarketNarrative;
