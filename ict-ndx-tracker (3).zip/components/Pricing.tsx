import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, CreditCard, Smartphone, Bitcoin, X, Loader2, Copy, ChevronLeft, Zap, Star, ShieldCheck } from 'lucide-react';
import { auth, db, OperationType, handleFirestoreError } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';

interface PricingProps {
  isOpen: boolean;
  onClose: () => void;
}

const Pricing: React.FC<PricingProps> = ({ isOpen, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [transactionCode, setTransactionCode] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'mpesa' | 'crypto' | null>(null);
  const [copied, setCopied] = useState(false);

  const TRC20_ADDRESS = 'TJjfQa3GYP5GbQYaW4WtM8Q4eUD8UcykoY';
  const MPESA_NUMBER = '0727993501';

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerifyPayment = async () => {
    if (!transactionCode || !auth.currentUser) return;
    setVerifying(true);
    const path = `users/${auth.currentUser.uid}`;
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, {
        isPremium: true,
        lastTransactionCode: transactionCode,
        premiumActivatedAt: new Date()
      });
      alert('Premium Activated Successfully! Welcome to Tecrypto Elite.');
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
      alert('Failed to verify payment. Please contact support.');
    } finally {
      setVerifying(false);
    }
  };

  const handleMPesaPayment = async () => {
    if (!phoneNumber) return;
    setLoading(true);
    try {
      const response = await fetch('/api/payments/mpesa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: phoneNumber.replace('+', ''), amount: 2100 }) // ~ $16 in KES
      });
      const data = await response.json();
      if (data.ResponseCode === '0') {
        alert('STK Push sent! Please check your phone to complete the payment.');
      } else {
        alert('Failed to trigger M-Pesa payment.');
      }
    } catch (error) {
      console.error('M-Pesa payment error:', error);
      alert('An error occurred during M-Pesa payment.');
    } finally {
      setLoading(false);
    }
  };

  const handleCryptoPayment = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/payments/crypto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: 16, currency: 'USD' }) // $16
      });
      const data = await response.json();
      if (data.hosted_url) {
        window.open(data.hosted_url, '_blank');
      } else {
        alert('Failed to create crypto payment.');
      }
    } catch (error) {
      console.error('Crypto payment error:', error);
      alert('An error occurred during crypto payment.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl"
        >
          <div className="p-6 border-b border-zinc-800 flex justify-between items-center">
            <div className="flex items-center gap-2">
              {paymentMethod && (
                <button 
                  onClick={() => setPaymentMethod(null)}
                  className="p-2 hover:bg-zinc-800 rounded-lg transition-colors mr-1"
                >
                  <ChevronLeft className="w-5 h-5 text-zinc-400" />
                </button>
              )}
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-primary" />
                {paymentMethod ? `Pay with ${paymentMethod === 'mpesa' ? 'M-Pesa' : 'Bybit'}` : 'Upgrade to Premium'}
              </h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-zinc-800 rounded-lg transition-colors">
              <X className="w-5 h-5 text-zinc-400" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {!paymentMethod && (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div className="bg-zinc-800/50 rounded-xl p-4 border border-zinc-700/50">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-zinc-400 text-sm">Premium Plan</span>
                    <span className="text-primary font-bold">$16 / month</span>
                  </div>
                  <ul className="space-y-2">
                    {['Real-time NDX 100 Data', 'Advanced ICT Concept Detection', 'Unlimited AI Market Analysis', 'Priority Support'].map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                        <Check className="w-4 h-4 text-primary" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">Select Payment Method</h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => setPaymentMethod('mpesa')}
                      className="p-6 rounded-xl border bg-zinc-800 border-zinc-700 text-zinc-400 hover:bg-zinc-700 hover:border-primary/50 transition-all flex flex-col items-center gap-3 group"
                    >
                      <div className="p-3 bg-zinc-900 rounded-full group-hover:bg-primary/20 transition-colors">
                        <Smartphone className="w-8 h-8 group-hover:text-primary transition-colors" />
                      </div>
                      <span className="text-sm font-bold text-white">M-Pesa</span>
                    </button>
                    <button
                      onClick={() => setPaymentMethod('crypto')}
                      className="p-6 rounded-xl border bg-zinc-800 border-zinc-700 text-zinc-400 hover:bg-zinc-700 hover:border-primary/50 transition-all flex flex-col items-center gap-3 group"
                    >
                      <div className="p-3 bg-zinc-900 rounded-full group-hover:bg-primary/20 transition-colors">
                        <Bitcoin className="w-8 h-8 group-hover:text-primary transition-colors" />
                      </div>
                      <span className="text-sm font-bold text-white">Bybit</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="space-y-4">
              {paymentMethod === 'mpesa' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-4"
                >
                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                    <p className="text-xs text-zinc-400 mb-1 uppercase font-bold">Send Money to:</p>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-mono font-bold text-white">{MPESA_NUMBER}</span>
                      <button 
                        onClick={() => copyToClipboard(MPESA_NUMBER)}
                        className="p-2 hover:bg-white/10 rounded-lg transition-colors text-primary"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-2 italic">
                      After sending, please contact support with your transaction code.
                    </p>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t border-zinc-800"></span>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-zinc-900 px-2 text-zinc-500">Or use STK Push</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs text-zinc-500 uppercase font-bold">Your Phone Number</label>
                    <input
                      type="text"
                      placeholder="254712345678"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-primary transition-colors"
                    />
                  </div>
                  <button
                    onClick={handleMPesaPayment}
                    disabled={loading || !phoneNumber}
                    className="w-full py-3 bg-primary hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Request STK Push'}
                  </button>

                  <div className="relative pt-4">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t border-zinc-800"></span>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-zinc-900 px-2 text-zinc-500">Already Paid?</span>
                    </div>
                  </div>

                  <div className="bg-zinc-800/50 border border-zinc-700 rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-white uppercase">
                      <ShieldCheck className="w-4 h-4 text-primary" />
                      Verify Transaction
                    </div>
                    <p className="text-[10px] text-zinc-400">
                      Paste your M-Pesa transaction code (e.g., RCK1234567) below to activate premium instantly.
                    </p>
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Transaction Code"
                        value={transactionCode}
                        onChange={(e) => setTransactionCode(e.target.value.toUpperCase())}
                        className="w-full bg-black/40 border border-zinc-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-primary transition-colors font-mono uppercase"
                      />
                      <button
                        onClick={handleVerifyPayment}
                        disabled={verifying || !transactionCode}
                        className="w-full py-2 bg-zinc-700 hover:bg-zinc-600 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2"
                      >
                        {verifying ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Activate Premium'}
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {paymentMethod === 'crypto' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-4"
                >
                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                    <p className="text-xs text-zinc-400 mb-1 uppercase font-bold">TRC20 Address (USDT/TRX):</p>
                    <div className="flex items-center gap-2 bg-black/40 p-3 rounded-lg border border-zinc-800">
                      <span className="text-[10px] font-mono text-zinc-300 break-all flex-1">{TRC20_ADDRESS}</span>
                      <button 
                        onClick={() => copyToClipboard(TRC20_ADDRESS)}
                        className="p-2 hover:bg-white/10 rounded-lg transition-colors text-primary shrink-0"
                      >
                        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-2 italic">
                      Send exactly $16 USDT (TRC20). Verification is manual.
                    </p>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t border-zinc-800"></span>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-zinc-900 px-2 text-zinc-500">Or Pay with Bybit</span>
                    </div>
                  </div>

                  <button
                    onClick={handleCryptoPayment}
                    disabled={loading}
                    className="w-full py-3 bg-primary hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Pay with Bybit'}
                  </button>
                </motion.div>
              )}
            </div>
          </div>

          <div className="p-6 bg-zinc-800/30 border-t border-zinc-800">
            <p className="text-xs text-zinc-500 text-center">
              Secure payments. Your data is encrypted and protected.
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default Pricing;
