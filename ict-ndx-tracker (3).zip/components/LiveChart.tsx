
import React, { useEffect, useRef, useState, useLayoutEffect, useCallback } from 'react';
import { createChart, ColorType, CandlestickSeries, LineSeries, CandlestickData, Time, HistogramSeries, ISeriesApi, CrosshairMode, IPriceLine, MouseEventParams, BarPrice } from 'lightweight-charts';
import { Activity, Wifi, WifiOff, Zap, Layers, XCircle, Target, ShieldAlert, MousePointer2, Minus, TrendingUp, TrendingDown, Settings, X, Save, Globe, Eraser, PenTool, Percent, LineChart, Eye, EyeOff, Trash2, Sliders, Magnet, Move } from 'lucide-react';
import { ICT_SESSIONS } from '../constants';
import { brokerService } from '../services/brokerService';
import { Position } from '../types';

const TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h', 'D'];
const DEFAULT_SYMBOL = 'QQQ'; // Nasdaq 100 ETF Proxy

// --- Types for ICT Concepts ---
interface OrderBlock { id: string; type: 'Bullish' | 'Bearish'; top: number; bottom: number; startTime: number; }
interface FairValueGap { id: string; type: 'Bullish' | 'Bearish'; top: number; bottom: number; startTime: number; }
interface BreakerBlock { id: string; type: 'Bullish' | 'Bearish'; top: number; bottom: number; startTime: number; breakTime: number; mitigated?: boolean; }

interface TimeframeAnalysis {
  timeframe: string;
  bias: 'Bullish' | 'Bearish' | 'Neutral';
  trend: 'Up' | 'Down' | 'Sideways';
  structure: 'HH/HL' | 'LH/LL' | 'Ranging';
  emaAlignment: 'Bullish' | 'Bearish' | 'Neutral';
  lastPrice: number;
}

interface DrawingObject { 
  id: string; 
  type: 'trendline' | 'fib'; 
  p1: { time: Time; price: number }; 
  p2: { time: Time; price: number }; 
  sl?: number; // Stop Loss Price
  tp?: number; // Take Profit Price
  color?: string;
  lineWidth?: number;
}

// --- Data Feed Interface ---
interface DataFeed {
  connect: () => void;
  close: () => void;
}

// --- Mock WebSocket ---
class MockFeed implements DataFeed {
  private intervalId: any; 
  private currentPrice: number = 21500.00;
  private currentCandle: any = null;
  private lastCandleTime: number = 0;
  private timeframe: string;
  private onHistory: (data: any[]) => void;
  private onUpdate: (data: any) => void;

  constructor(timeframe: string, onHistory: (data: any[]) => void, onUpdate: (data: any) => void) {
    this.timeframe = timeframe;
    this.onHistory = onHistory;
    this.onUpdate = onUpdate;
  }

  connect() {
    this.generateHistory();
    this.startStreaming();
  }

  close() {
    if (this.intervalId) clearInterval(this.intervalId);
  }

  private getIntervalSeconds() {
    switch(this.timeframe) { case '1m': return 60; case '5m': return 300; case '15m': return 900; case '1h': return 3600; case '4h': return 14400; case 'D': return 86400; default: return 60; }
  }

  private generateHistory() {
    const now = Math.floor(Date.now() / 1000); 
    const interval = this.getIntervalSeconds(); 
    const count = 300; 
    const data = []; 
    let price = this.currentPrice;
    
    for (let i = count; i > 0; i--) {
      const time = now - (i * interval); 
      const volatility = price * 0.0015;
      const change = (Math.random() - 0.5) * volatility;
      const open = price; 
      const close = open + change; 
      const high = Math.max(open, close) + Math.random() * (volatility * 0.5); 
      const low = Math.min(open, close) - Math.random() * (volatility * 0.5);
      data.push({ time: time as Time, open, high, low, close }); 
      price = close;
    }
    this.currentPrice = price; 
    this.lastCandleTime = data[data.length - 1].time as number;
    this.currentCandle = { time: (this.lastCandleTime + interval) as Time, open: price, high: price, low: price, close: price };
    this.onHistory(data);
  }

  private startStreaming() {
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      const volatility = this.currentPrice * 0.0001; 
      const change = (Math.random() - 0.5) * volatility; 
      const newPrice = this.currentPrice + change;
      
      this.currentCandle.close = newPrice; 
      this.currentCandle.high = Math.max(this.currentCandle.high, newPrice);
      this.currentCandle.low = Math.min(this.currentCandle.low, newPrice); 
      this.currentPrice = newPrice;
      
      const now = Math.floor(Date.now() / 1000); 
      const interval = this.getIntervalSeconds();
      
      if (now >= (this.currentCandle.time as number) + interval) {
        this.lastCandleTime = this.currentCandle.time as number; 
        const close = this.currentCandle.close;
        this.currentCandle = { time: (this.lastCandleTime + interval) as Time, open: close, high: close, low: close, close: close };
      }
      this.onUpdate(this.currentCandle);
    }, 500);
  }
}

// --- Finnhub Feed ---
class FinnhubFeed implements DataFeed {
  private socket: WebSocket | null = null;
  private apiKey: string;
  private symbol: string;
  private timeframe: string;
  private onHistory: (data: any[]) => void;
  private onUpdate: (data: any) => void;
  private onError: (err: string) => void;
  private lastCandle: any = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 3;
  private isClosed = false;

  constructor(apiKey: string, symbol: string, timeframe: string, onHistory: any, onUpdate: any, onError: any) {
    this.apiKey = apiKey;
    this.symbol = symbol;
    this.timeframe = timeframe;
    this.onHistory = onHistory;
    this.onUpdate = onUpdate;
    this.onError = onError;
  }

  private getResolution() {
    const map: Record<string, string> = { '1m': '1', '5m': '5', '15m': '15', '1h': '60', '4h': '240', 'D': 'D' };
    return map[this.timeframe] || '1';
  }

  private getIntervalSeconds() {
     const res = this.getResolution();
     if (res === 'D') return 86400;
     return parseInt(res) * 60;
  }

  async connect() {
    try {
        const resolution = this.getResolution();
        const now = Math.floor(Date.now() / 1000);
        const from = now - (resolution === 'D' ? 86400 * 300 : 86400 * 4); 
        
        const response = await fetch(`https://finnhub.io/api/v1/stock/candle?symbol=${this.symbol}&resolution=${resolution}&from=${from}&to=${now}&token=${this.apiKey}`);
        
        if (!response.ok) {
            if (response.status === 401) {
                this.onError('Invalid Finnhub API Key. Please check your settings.');
            } else if (response.status === 403) {
                this.onError('Access forbidden. Your API key might not have access to this symbol.');
            } else if (response.status === 429) {
                this.onError('Finnhub API rate limit exceeded. Please wait a moment.');
            } else {
                this.onError(`Finnhub API error: ${response.statusText}`);
            }
            return;
        }

        const data = await response.json();
        
        if (data.s === 'ok') {
            const candles = data.t.map((t: number, i: number) => ({
                time: t as Time, open: data.o[i], high: data.h[i], low: data.l[i], close: data.c[i]
            }));
            this.lastCandle = candles[candles.length - 1];
            this.onHistory(candles);
            this.connectWebSocket();
        } else if (data.s === 'no_data') {
            this.onError(`No data found for symbol ${this.symbol}. Ensure the symbol is correct and active.`);
        } else {
            this.onError(`Failed to load history for ${this.symbol}: ${data.error || 'Unknown error'}`);
        }
    } catch (e) {
        this.onError('Network error fetching history. Check your internet connection.');
    }
  }

  connectWebSocket() {
    if (this.isClosed) return;
    
    this.socket = new WebSocket(`wss://ws.finnhub.io?token=${this.apiKey}`);
    
    this.socket.onopen = () => {
        this.reconnectAttempts = 0;
        this.socket?.send(JSON.stringify({type: 'subscribe', symbol: this.symbol}));
    };

    this.socket.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.type === 'error') {
            this.onError(`WebSocket Error: ${msg.msg}`);
            return;
        }
        if (msg.type === 'trade') {
            const trades = msg.data;
            if (!trades || trades.length === 0) return;

            const latestTrade = trades[trades.length - 1];
            const price = latestTrade.p;
            const time = latestTrade.t; 

            const interval = this.getIntervalSeconds();
            const tradeTimeSec = Math.floor(time / 1000);
            const candleStartTime = Math.floor(tradeTimeSec / interval) * interval;

            if (this.lastCandle) {
                if (candleStartTime === this.lastCandle.time) {
                    this.lastCandle.close = price;
                    this.lastCandle.high = Math.max(this.lastCandle.high, price);
                    this.lastCandle.low = Math.min(this.lastCandle.low, price);
                } else if (candleStartTime > (this.lastCandle.time as number)) {
                    this.lastCandle = {
                        time: candleStartTime as Time,
                        open: price,
                        high: price,
                        low: price,
                        close: price
                    };
                }
                this.onUpdate({ ...this.lastCandle });
            } else {
                 this.lastCandle = {
                    time: candleStartTime as Time,
                    open: price,
                    high: price,
                    low: price,
                    close: price
                };
                this.onUpdate({ ...this.lastCandle });
            }
        }
    };
    
    this.socket.onclose = () => {
        if (!this.isClosed && this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            const delay = Math.pow(2, this.reconnectAttempts) * 1000;
            setTimeout(() => this.connectWebSocket(), delay);
        }
    };

    this.socket.onerror = (e) => {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            this.onError('WebSocket connection error. Real-time updates may be unavailable.');
        }
    };
  }

  close() {
    this.isClosed = true;
    this.socket?.close();
  }
}

// --- Indicators Logic ---
const calculateSMA = (data: CandlestickData[], period: number) => {
  const smaData = [];
  for (let i = period - 1; i < data.length; i++) {
    const sum = data.slice(i - period + 1, i + 1).reduce((acc, val) => acc + val.close, 0);
    smaData.push({ time: data[i].time, value: sum / period });
  }
  return smaData;
};

const calculateEMA = (data: CandlestickData[], period: number) => {
  const k = 2 / (period + 1);
  const emaData = [];
  let ema = data[0].close;
  for (let i = 0; i < data.length; i++) {
    ema = data[i].close * k + ema * (1 - k);
    if (i >= period - 1) {
      emaData.push({ time: data[i].time, value: ema });
    }
  }
  return emaData;
};

type DrawingTool = 'cursor' | 'trendline' | 'fib' | 'horizontal';

// --- Reusable Toolbar Button ---
const ToolbarButton = ({ 
  active, 
  onClick, 
  icon: Icon, 
  label,
  danger = false
}: { 
  active?: boolean; 
  onClick: () => void; 
  icon: any; 
  label: string;
  danger?: boolean;
}) => (
  <button 
    onClick={onClick}
    className={`
      relative group p-2.5 rounded-xl transition-all duration-200 flex items-center justify-center
      ${active 
        ? 'bg-primary/20 text-primary shadow-[0_0_12px_rgba(16,185,129,0.3)] ring-1 ring-primary/50' 
        : danger 
          ? 'text-gray-400 hover:bg-red-500/20 hover:text-red-400 hover:shadow-[0_0_12px_rgba(239,68,68,0.2)]' 
          : 'text-gray-400 hover:bg-white/10 hover:text-white hover:shadow-lg'
      }
    `}
  >
    <Icon className={`w-5 h-5 ${active ? 'stroke-[2.5px]' : 'stroke-2'}`} />
    
    {/* Enhanced Tooltip */}
    <div className="absolute left-full top-1/2 -translate-y-1/2 ml-3 px-3 py-1.5 bg-[#09090b] border border-white/20 rounded-lg text-[11px] font-semibold text-white opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none whitespace-nowrap z-50 shadow-2xl backdrop-blur-md translate-x-2 group-hover:translate-x-0">
      {label}
      <div className="absolute top-1/2 -left-1.5 -translate-y-1/2 border-[6px] border-transparent border-r-white/20"></div>
      <div className="absolute top-1/2 -left-[5px] -translate-y-1/2 border-[5px] border-transparent border-r-[#09090b]"></div>
    </div>
  </button>
);

const LiveChart: React.FC = () => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<any>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const smaSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  const emaSeriesRef = useRef<ISeriesApi<"Line"> | null>(null);
  
  // State
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [timeframe, setTimeframe] = useState('1m');
  const [dataSource, setDataSource] = useState<'mock' | 'finnhub'>('mock');
  const [finnhubKey, setFinnhubKey] = useState(localStorage.getItem('finnhub_key') || '');
  const [symbol, setSymbol] = useState(localStorage.getItem('finnhub_symbol') || DEFAULT_SYMBOL);
  const [showSettings, setShowSettings] = useState(false);
  
  // Indicators
  const [indicators, setIndicators] = useState({ sma: false, ema: false });
  const [showKillZones, setShowKillZones] = useState(localStorage.getItem('show_killzones') !== 'false');
  const [showOrderBlocks, setShowOrderBlocks] = useState(localStorage.getItem('show_orderblocks') !== 'false');
  const [showFvgs, setShowFvgs] = useState(localStorage.getItem('show_fvgs') !== 'false');
  const [showBreakers, setShowBreakers] = useState(localStorage.getItem('show_breakers') !== 'false');

  // Drawing Tools
  const [activeTool, setActiveTool] = useState<DrawingTool>('cursor');
  const [drawings, setDrawings] = useState<DrawingObject[]>([]);
  const [tempDrawing, setTempDrawing] = useState<Partial<DrawingObject> | null>(null);
  const [selectedDrawingId, setSelectedDrawingId] = useState<string | null>(null);
  const [panelPos, setPanelPos] = useState<{ x: number, y: number } | null>(null);
  const [hoveredDrawingId, setHoveredDrawingId] = useState<string | null>(null);
  const [dragHandle, setDragHandle] = useState<{ id: string, handle: 'p1' | 'p2' | 'sl' | 'tp' } | null>(null);
  const [chartCursor, setChartCursor] = useState<{time: Time, price: number} | null>(null);
  
  // Snap State
  const hoveredCandleRef = useRef<CandlestickData | null>(null);
  const [isSnapEnabled, setIsSnapEnabled] = useState(true);

  // Broker
  const [brokerConnected, setBrokerConnected] = useState(false);
  const [positions, setPositions] = useState<Position[]>([]);
  const [lotSize, setLotSize] = useState(1.0);
  const [tpPrice, setTpPrice] = useState<string>('');
  const [slPrice, setSlPrice] = useState<string>('');
  const [processingOrder, setProcessingOrder] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  // Feed Status
  const [feedStatus, setFeedStatus] = useState<'idle' | 'connecting' | 'connected' | 'error'>('idle');
  const [feedError, setFeedError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  // Refs for data persistence across renders
  const fullCandleDataRef = useRef<CandlestickData[]>([]);
  const currentPriceLineRef = useRef<IPriceLine | null>(null);
  const lastUpdateRef = useRef<number>(0);

  // ICT Concepts Data
  const [orderBlocks, setOrderBlocks] = useState<OrderBlock[]>([]);
  const [fvgs, setFvgs] = useState<FairValueGap[]>([]);
  const [breakerBlocks, setBreakerBlocks] = useState<BreakerBlock[]>([]);

  // MTF Analysis State
  const [mtfAnalyses, setMtfAnalyses] = useState<Record<string, TimeframeAnalysis>>({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [narrative, setNarrative] = useState<string>('');
  const [overallBias, setOverallBias] = useState<'Bullish' | 'Bearish' | 'Neutral'>('Neutral');

  // SVG Overlay Sync
  const svgRef = useRef<SVGSVGElement>(null);
  const [svgVersion, setSvgVersion] = useState(0); // Force re-render of SVG

  const showNotificationMsg = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const saveSettings = () => {
      localStorage.setItem('finnhub_key', finnhubKey);
      localStorage.setItem('finnhub_symbol', symbol);
      localStorage.setItem('show_killzones', showKillZones.toString());
      localStorage.setItem('show_orderblocks', showOrderBlocks.toString());
      localStorage.setItem('show_fvgs', showFvgs.toString());
      localStorage.setItem('show_breakers', showBreakers.toString());
      setShowSettings(false);
      if (dataSource === 'finnhub') window.location.reload(); 
  };

  // --- Concept Detection ---
  const detectICTConcepts = (data: CandlestickData[]) => {
    if (data.length < 20) return;
    
    const obs: OrderBlock[] = []; 
    const detectedFvgs: FairValueGap[] = [];
    const breakers: BreakerBlock[] = [];
    
    const lookback = Math.min(data.length - 5, 250);
    const startIdx = data.length - lookback;

    // 1. Find Swing Points (Fractals)
    const swingHighs: { idx: number; val: number; time: number }[] = [];
    const swingLows: { idx: number; val: number; time: number }[] = [];

    for (let i = 2; i < data.length - 2; i++) {
        // Swing High (5-bar fractal)
        if (data[i].high > data[i-1].high && data[i].high > data[i-2].high && 
            data[i].high > data[i+1].high && data[i].high > data[i+2].high) {
            swingHighs.push({ idx: i, val: data[i].high, time: data[i].time as number });
        }
        // Swing Low (5-bar fractal)
        if (data[i].low < data[i-1].low && data[i].low < data[i-2].low && 
            data[i].low < data[i+1].low && data[i].low < data[i+2].low) {
            swingLows.push({ idx: i, val: data[i].low, time: data[i].time as number });
        }
    }

    // 2. Detect Fair Value Gaps (FVG) with Displacement
    for (let i = startIdx; i < data.length - 2; i++) {
        const c1 = data[i];
        const c2 = data[i+1];
        const c3 = data[i+2];

        // Bullish FVG: Gap between C1 High and C3 Low
        if (c3.low > c1.high) {
            const gapSize = c3.low - c1.high;
            const candleSize = Math.abs(c2.close - c2.open);
            // Displacement check: The middle candle should be a strong expansion
            if (candleSize > gapSize * 0.3) {
                let mitigated = false;
                // Check if price has returned to fill the gap
                for (let j = i + 3; j < data.length; j++) {
                    if (data[j].low <= c1.high) { mitigated = true; break; }
                }
                if (!mitigated) {
                    detectedFvgs.push({ 
                        id: `bull-fvg-${c2.time}`, 
                        type: 'Bullish', 
                        top: c3.low, 
                        bottom: c1.high, 
                        startTime: c2.time as number 
                    });
                }
            }
        }
        // Bearish FVG: Gap between C1 Low and C3 High
        if (c3.high < c1.low) {
            const gapSize = c1.low - c3.high;
            const candleSize = Math.abs(c2.close - c2.open);
            if (candleSize > gapSize * 0.3) {
                let mitigated = false;
                for (let j = i + 3; j < data.length; j++) {
                    if (data[j].high >= c1.low) { mitigated = true; break; }
                }
                if (!mitigated) {
                    detectedFvgs.push({ 
                        id: `bear-fvg-${c2.time}`, 
                        type: 'Bearish', 
                        top: c1.low, 
                        bottom: c3.high, 
                        startTime: c2.time as number 
                    });
                }
            }
        }
    }

    // 3. Detect Order Blocks (OB) with Market Structure Shift (MSS)
    // We look for the last candle of opposite color before a move that breaks a recent swing point
    for (let i = startIdx; i < data.length - 5; i++) {
        // Bullish OB: Last down candle before a break of a recent swing high
        if (data[i].close < data[i].open) {
            let bos = false;
            let bosIdx = -1;
            const recentHighs = swingHighs.filter(h => h.idx < i && h.idx > i - 30);
            if (recentHighs.length > 0) {
                const highest = Math.max(...recentHighs.map(h => h.val));
                for (let j = i + 1; j < i + 15 && j < data.length; j++) {
                    if (data[j].close > highest) {
                        bos = true;
                        bosIdx = j;
                        break;
                    }
                }
            }

            if (bos) {
                // Check for displacement (strong move up)
                const moveUp = data[bosIdx].close - data[i].low;
                if (moveUp > (data[i].high - data[i].low) * 1.5) {
                    let mitigated = false;
                    for (let k = bosIdx + 1; k < data.length; k++) {
                        if (data[k].low < data[i].low) { mitigated = true; break; }
                    }
                    if (!mitigated) {
                        obs.push({ 
                            id: `bull-ob-${data[i].time}`, 
                            type: 'Bullish', 
                            top: Math.max(data[i].open, data[i].high), 
                            bottom: data[i].low, 
                            startTime: data[i].time as number 
                        });
                    }
                }
            }
        }

        // Bearish OB: Last up candle before a break of a recent swing low
        if (data[i].close > data[i].open) {
            let bos = false;
            let bosIdx = -1;
            const recentLows = swingLows.filter(l => l.idx < i && l.idx > i - 30);
            if (recentLows.length > 0) {
                const lowest = Math.min(...recentLows.map(l => l.val));
                for (let j = i + 1; j < i + 15 && j < data.length; j++) {
                    if (data[j].close < lowest) {
                        bos = true;
                        bosIdx = j;
                        break;
                    }
                }
            }

            if (bos) {
                const moveDown = data[i].high - data[bosIdx].close;
                if (moveDown > (data[i].high - data[i].low) * 1.5) {
                    let mitigated = false;
                    for (let k = bosIdx + 1; k < data.length; k++) {
                        if (data[k].high > data[i].high) { mitigated = true; break; }
                    }
                    if (!mitigated) {
                        obs.push({ 
                            id: `bear-ob-${data[i].time}`, 
                            type: 'Bearish', 
                            top: data[i].high, 
                            bottom: Math.min(data[i].open, data[i].low), 
                            startTime: data[i].time as number 
                        });
                    }
                }
            }
        }
    }

    // 4. Breaker Blocks
    // Bullish Breaker: Price makes a Lower Low (liquidity grab), then breaks above the previous Lower High.
    // Pattern: L1 -> H1 -> L2 (L2 < L1) -> Price > H1
    for (let i = 0; i < swingLows.length - 1; i++) {
        const l1 = swingLows[i];
        const l2 = swingLows[i+1];
        
        if (l2.val < l1.val && l2.idx > l1.idx) {
            // Find the highest swing high between L1 and L2
            const highsBetween = swingHighs.filter(h => h.idx > l1.idx && h.idx < l2.idx);
            if (highsBetween.length > 0) {
                const h1 = highsBetween.reduce((prev, curr) => (curr.val > prev.val) ? curr : prev);
                
                let broke = false;
                let breakTime = 0;
                let breakIdx = -1;
                
                for (let k = l2.idx + 1; k < data.length; k++) {
                    if (data[k].close > h1.val) {
                        broke = true;
                        breakTime = data[k].time as number;
                        breakIdx = k;
                        break;
                    }
                }
                
                if (broke) {
                    // Check for displacement (strong move up)
                    const moveUp = data[breakIdx].close - data[l2.idx].low;
                    const avgCandleSize = data.slice(l2.idx, breakIdx + 1).reduce((acc, val) => acc + (val.high - val.low), 0) / (breakIdx - l2.idx + 1);
                    
                    if (moveUp > avgCandleSize * 1.5) {
                        // Check for mitigation
                        let isMitigated = false;
                        const breakerBottom = data[h1.idx].low;
                        for (let m = breakIdx + 1; m < data.length; m++) {
                            if (data[m].low < breakerBottom) { isMitigated = true; break; }
                        }
                        
                        breakers.push({ 
                            id: `bull-brk-${h1.time}`, 
                            type: 'Bullish', 
                            top: data[h1.idx].high, 
                            bottom: data[h1.idx].low, 
                            startTime: h1.time, 
                            breakTime,
                            mitigated: isMitigated
                        });
                    }
                }
            }
        }
    }

    // Bearish Breaker: Price makes a Higher High (liquidity grab), then breaks below the previous Higher Low.
    // Pattern: H1 -> L1 -> H2 (H2 > H1) -> Price < L1
    for (let i = 0; i < swingHighs.length - 1; i++) {
        const h1 = swingHighs[i];
        const h2 = swingHighs[i+1];
        
        if (h2.val > h1.val && h2.idx > h1.idx) {
            // Find the lowest swing low between H1 and H2
            const lowsBetween = swingLows.filter(l => l.idx > h1.idx && l.idx < h2.idx);
            if (lowsBetween.length > 0) {
                const l1 = lowsBetween.reduce((prev, curr) => (curr.val < prev.val) ? curr : prev);
                
                let broke = false;
                let breakTime = 0;
                let breakIdx = -1;
                
                for (let k = h2.idx + 1; k < data.length; k++) {
                    if (data[k].close < l1.val) {
                        broke = true;
                        breakTime = data[k].time as number;
                        breakIdx = k;
                        break;
                    }
                }
                
                if (broke) {
                    // Check for displacement (strong move down)
                    const moveDown = data[h2.idx].high - data[breakIdx].close;
                    const avgCandleSize = data.slice(h2.idx, breakIdx + 1).reduce((acc, val) => acc + (val.high - val.low), 0) / (breakIdx - h2.idx + 1);

                    if (moveDown > avgCandleSize * 1.5) {
                        let isMitigated = false;
                        const breakerTop = data[l1.idx].high;
                        for (let m = breakIdx + 1; m < data.length; m++) {
                            if (data[m].high > breakerTop) { isMitigated = true; break; }
                        }
                        
                        breakers.push({ 
                            id: `bear-brk-${l1.time}`, 
                            type: 'Bearish', 
                            top: data[l1.idx].high, 
                            bottom: data[l1.idx].low, 
                            startTime: l1.time, 
                            breakTime,
                            mitigated: isMitigated
                        });
                    }
                }
            }
        }
    }

    setFvgs(detectedFvgs.slice(-10)); 
    setOrderBlocks(obs.slice(-10));
    setBreakerBlocks(breakers.slice(-10));
  };

  // --- MTF Analysis Logic ---
  const analyzeTimeframeData = (tf: string, data: CandlestickData[]): TimeframeAnalysis => {
    if (data.length < 50) {
      return { timeframe: tf, bias: 'Neutral', trend: 'Sideways', structure: 'Ranging', emaAlignment: 'Neutral', lastPrice: data[data.length-1]?.close || 0 };
    }

    const last50 = data.slice(-50);
    const ema20 = calculateEMA(data, 20);
    const ema50 = calculateEMA(data, 50);
    
    const lastEma20 = ema20[ema20.length - 1]?.value || 0;
    const lastEma50 = ema50[ema50.length - 1]?.value || 0;
    const lastPrice = data[data.length - 1].close;

    // EMA Alignment
    let emaAlignment: 'Bullish' | 'Bearish' | 'Neutral' = 'Neutral';
    if (lastEma20 > lastEma50 && lastPrice > lastEma20) emaAlignment = 'Bullish';
    else if (lastEma20 < lastEma50 && lastPrice < lastEma20) emaAlignment = 'Bearish';

    // Structure (Simplified HH/HL detection)
    const highs = last50.map(d => d.high);
    const lows = last50.map(d => d.low);
    const maxHigh = Math.max(...highs);
    const minLow = Math.min(...lows);
    
    const firstHalf = last50.slice(0, 25);
    const secondHalf = last50.slice(25);
    const firstHalfHigh = Math.max(...firstHalf.map(d => d.high));
    const secondHalfHigh = Math.max(...secondHalf.map(d => d.high));
    const firstHalfLow = Math.min(...firstHalf.map(d => d.low));
    const secondHalfLow = Math.min(...secondHalf.map(d => d.low));

    let structure: 'HH/HL' | 'LH/LL' | 'Ranging' = 'Ranging';
    if (secondHalfHigh > firstHalfHigh && secondHalfLow > firstHalfLow) structure = 'HH/HL';
    else if (secondHalfHigh < firstHalfHigh && secondHalfLow < firstHalfLow) structure = 'LH/LL';

    // Trend
    let trend: 'Up' | 'Down' | 'Sideways' = 'Sideways';
    if (emaAlignment === 'Bullish' && structure === 'HH/HL') trend = 'Up';
    else if (emaAlignment === 'Bearish' && structure === 'LH/LL') trend = 'Down';

    // Bias
    let bias: 'Bullish' | 'Bearish' | 'Neutral' = 'Neutral';
    if (trend === 'Up') bias = 'Bullish';
    else if (trend === 'Down') bias = 'Bearish';

    return { timeframe: tf, bias, trend, structure, emaAlignment, lastPrice };
  };

  const runMTFAnalysis = async () => {
    if (!finnhubKey || dataSource !== 'finnhub') {
      // Mock MTF for demo
      const mockAnalyses: Record<string, TimeframeAnalysis> = {
        '1h': { timeframe: '1h', bias: 'Bullish', trend: 'Up', structure: 'HH/HL', emaAlignment: 'Bullish', lastPrice: currentPrice },
        '15m': { timeframe: '15m', bias: 'Bullish', trend: 'Up', structure: 'HH/HL', emaAlignment: 'Bullish', lastPrice: currentPrice },
        '5m': { timeframe: '5m', bias: 'Bearish', trend: 'Down', structure: 'LH/LL', emaAlignment: 'Bearish', lastPrice: currentPrice },
      };
      setMtfAnalyses(mockAnalyses);
      updateNarrative(mockAnalyses);
      return;
    }

    setIsAnalyzing(true);
    const tfs = ['1h', '15m', '5m'];
    const results: Record<string, TimeframeAnalysis> = {};

    try {
      for (const tf of tfs) {
        const resolution = tf === '1h' ? '60' : tf === '15m' ? '15' : '5';
        const now = Math.floor(Date.now() / 1000);
        const from = now - (86400 * 7); // 7 days of data
        
        const response = await fetch(`https://finnhub.io/api/v1/stock/candle?symbol=${symbol}&resolution=${resolution}&from=${from}&to=${now}&token=${finnhubKey}`);
        const data = await response.json();
        
        if (data.s === 'ok') {
          const candles = data.t.map((t: number, i: number) => ({
            time: t as Time, open: data.o[i], high: data.h[i], low: data.l[i], close: data.c[i]
          }));
          results[tf] = analyzeTimeframeData(tf, candles);
        }
      }
      setMtfAnalyses(results);
      updateNarrative(results);
    } catch (e) {
      console.error("MTF Analysis failed", e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const updateNarrative = (analyses: Record<string, TimeframeAnalysis>) => {
    const h1 = analyses['1h'];
    const m15 = analyses['15m'];
    const m5 = analyses['5m'];

    if (!h1 || !m15 || !m5) return;

    let text = "";
    let bias: 'Bullish' | 'Bearish' | 'Neutral' = 'Neutral';

    if (h1.bias === 'Bullish' && m15.bias === 'Bullish') {
      bias = 'Bullish';
      text = `The higher timeframe (1H) is clearly Bullish with ${h1.structure} structure. 15M is aligned, suggesting a strong trend. `;
      if (m5.bias === 'Bearish') {
        text += "5M is currently retracing, which could offer a high-probability long entry at an FVG or Order Block.";
      } else {
        text += "5M is also Bullish, indicating full alignment. Look for continuation plays.";
      }
    } else if (h1.bias === 'Bearish' && m15.bias === 'Bearish') {
      bias = 'Bearish';
      text = `The higher timeframe (1H) is Bearish with ${h1.structure} structure. 15M is aligned, confirming the downtrend. `;
      if (m5.bias === 'Bullish') {
        text += "5M is currently in a counter-trend rally, potentially providing a short entry at premium levels.";
      } else {
        text += "5M is also Bearish, indicating full alignment. Look for trend continuation shorts.";
      }
    } else {
      bias = 'Neutral';
      text = `Market is currently in a mixed state. 1H is ${h1.bias}, while 15M is ${m15.bias}. `;
      text += "Wait for timeframe alignment (HTF and LTF both showing same bias) before taking high-conviction trades.";
    }

    setNarrative(text);
    setOverallBias(bias);
  };

  useEffect(() => {
    if (dataSource === 'finnhub' && finnhubKey) {
      runMTFAnalysis();
      const interval = setInterval(runMTFAnalysis, 300000); // Every 5 mins
      return () => clearInterval(interval);
    } else {
      runMTFAnalysis(); // Mock
    }
  }, [symbol, finnhubKey, dataSource]);

  // --- Chart Initialization & Logic ---
  useEffect(() => {
    if (!chartContainerRef.current) return;
    
    let isChartDisposed = false;

    const chart = createChart(chartContainerRef.current, {
      layout: { background: { type: ColorType.Solid, color: '#18181b' }, textColor: '#d4d4d8' },
      grid: { vertLines: { color: '#27272a' }, horzLines: { color: '#27272a' } },
      width: chartContainerRef.current.clientWidth, height: 450,
      timeScale: { timeVisible: true, secondsVisible: false, rightOffset: 12 },
      crosshair: { mode: CrosshairMode.Normal },
    });
    chartRef.current = chart;

    // Series
    const candleSeries = chart.addSeries(CandlestickSeries, { 
      upColor: '#10b981', downColor: '#ef4444', borderVisible: false, 
      wickUpColor: '#10b981', wickDownColor: '#ef4444', priceLineVisible: false 
    });
    candleSeriesRef.current = candleSeries;

    const smaSeries = chart.addSeries(LineSeries, { color: '#facc15', lineWidth: 2, visible: false });
    smaSeriesRef.current = smaSeries;
    
    const emaSeries = chart.addSeries(LineSeries, { color: '#3b82f6', lineWidth: 2, visible: false });
    emaSeriesRef.current = emaSeries;

    const killZoneSeries = chart.addSeries(HistogramSeries, { priceScaleId: 'kz-scale', visible: showKillZones });
    chart.priceScale('kz-scale').applyOptions({ visible: false, autoScale: false });

    // Sync SVG on Scroll/Zoom/Resize
    const syncOverlay = () => {
       if (isChartDisposed) return;
       setSvgVersion(v => v + 1);
    };

    chart.timeScale().subscribeVisibleTimeRangeChange(syncOverlay);
    chart.timeScale().subscribeVisibleLogicalRangeChange(syncOverlay);
    
    // Resize observer for the container
    const resizeObserver = new ResizeObserver(entries => {
      if (isChartDisposed || !entries[0]) return;
      const { width, height } = entries[0].contentRect;
      chart.applyOptions({ width, height });
      syncOverlay();
    });
    resizeObserver.observe(chartContainerRef.current);

    // Drawing Interaction - Chart Click (used for coordinates only when needed)
    chart.subscribeCrosshairMove((param: MouseEventParams) => {
       if (isChartDisposed) return;
       if (param.time && param.seriesData.get(candleSeries)) {
          const price = param.seriesData.get(candleSeries) as any;
          setChartCursor({ time: param.time as Time, price: price.close || 0 }); 
          
          // Capture for Snap Logic
          hoveredCandleRef.current = param.seriesData.get(candleSeries) as CandlestickData;
       } else {
          hoveredCandleRef.current = null;
       }
    });

    // Handle background click to deselect
    chart.subscribeClick((param) => {
       if(activeTool === 'cursor' && !param.hoveredSeries && !param.hoveredObjectId) {
          // Check if we hit a drawing in DOM (handled by React), if not, this event fires
          // But lightweight charts doesn't know about our SVG drawings.
          // We'll rely on our own overlay click handler for deselection logic where possible,
          // but clicking on the chart background (canvas) might be captured here.
          // To be safe, we perform hit testing in handleMouseDown.
       }
    });

    // Feed Setup
    let feed: DataFeed | null = null;
    
    const updateIndicators = (data: CandlestickData[]) => {
       if (isChartDisposed) return;
       if (smaSeriesRef.current) smaSeriesRef.current.setData(calculateSMA(data, 20));
       if (emaSeriesRef.current) emaSeriesRef.current.setData(calculateEMA(data, 50));
    };

    const handleHistory = (data: any[]) => {
       if (isChartDisposed) return;
       setFeedStatus('connected');
       setFeedError(null);
       fullCandleDataRef.current = data;
       candleSeries.setData(data);
       updateIndicators(data);
       detectICTConcepts(data);
       
       const kzData = data.map((d: any) => {
         const session = ICT_SESSIONS.find(s => {
           const timeStr = new Date(d.time * 1000).toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour12: false, hour: '2-digit', minute: '2-digit' });
           return s.startLocal > s.endLocal ? (timeStr >= s.startLocal || timeStr < s.endLocal) : (timeStr >= s.startLocal && timeStr < s.endLocal);
         });
         
         const color = session 
             ? (session.type === 'Asian' ? 'rgba(59, 130, 246, 0.15)' 
                : session.type === 'London' ? 'rgba(245, 158, 11, 0.15)' 
                : session.type === 'NewYork' ? 'rgba(249, 115, 22, 0.15)' 
                : 'rgba(168, 85, 247, 0.15)') 
             : 'transparent';

         return { time: d.time, value: session ? 1 : 0, color };
       });
       killZoneSeries.setData(kzData);

       if (data.length > 0) {
         const last = data[data.length - 1];
         setCurrentPrice(last.close);
         if (!currentPriceLineRef.current) currentPriceLineRef.current = candleSeries.createPriceLine({ price: last.close, color: '#f59e0b', lineWidth: 1, lineStyle: 2, axisLabelVisible: true, title: 'PRICE' });
         else currentPriceLineRef.current.applyOptions({ price: last.close });
       }
    };

    const handleUpdate = (candle: any) => {
      if (isChartDisposed) return;
      setFeedStatus('connected');
      setFeedError(null);
      candleSeries.update(candle);
      // Append to ref
      const last = fullCandleDataRef.current[fullCandleDataRef.current.length - 1];
      if (last.time === candle.time) fullCandleDataRef.current[fullCandleDataRef.current.length - 1] = candle;
      else fullCandleDataRef.current.push(candle);

      if (Date.now() - lastUpdateRef.current > 1000) {
         updateIndicators(fullCandleDataRef.current);
         detectICTConcepts(fullCandleDataRef.current);
         lastUpdateRef.current = Date.now();
      }

      // Update Kill Zone for new candle
      const session = ICT_SESSIONS.find(s => {
           const timeStr = new Date(candle.time * 1000).toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour12: false, hour: '2-digit', minute: '2-digit' });
           return s.startLocal > s.endLocal ? (timeStr >= s.startLocal || timeStr < s.endLocal) : (timeStr >= s.startLocal && timeStr < s.endLocal);
      });
      const kzColor = session 
             ? (session.type === 'Asian' ? 'rgba(59, 130, 246, 0.15)' 
                : session.type === 'London' ? 'rgba(245, 158, 11, 0.15)' 
                : session.type === 'NewYork' ? 'rgba(249, 115, 22, 0.15)' 
                : 'rgba(168, 85, 247, 0.15)') 
             : 'transparent';
      
      killZoneSeries.update({ time: candle.time, value: session ? 1 : 0, color: kzColor });

      if (currentPriceLineRef.current) currentPriceLineRef.current.applyOptions({ price: candle.close });
      setCurrentPrice(candle.close);
    };

    const handleError = (msg: string) => {
        setFeedStatus('error');
        setFeedError(msg);
        if (!isChartDisposed) showNotificationMsg(msg, "error");
    };

    if (dataSource === 'finnhub') {
        if (!finnhubKey || !symbol) { 
            if (!finnhubKey) showNotificationMsg("Please provide a Finnhub API Key in settings.", "error");
            else if (!symbol) showNotificationMsg("Please provide a symbol to track.", "error");
            setShowSettings(true); 
            setDataSource('mock'); 
        }
        else { 
            setFeedStatus('connecting');
            feed = new FinnhubFeed(finnhubKey, symbol, timeframe, handleHistory, handleUpdate, handleError); 
            feed.connect(); 
        }
    } else {
        setFeedStatus('connected');
        feed = new MockFeed(timeframe, handleHistory, handleUpdate);
        feed.connect();
    }

    const handleResize = () => {
      if (isChartDisposed || !chartContainerRef.current) return;
      chart.applyOptions({ width: chartContainerRef.current.clientWidth });
      setSvgVersion(v => v + 1);
    };
    window.addEventListener('resize', handleResize);
    
    return () => { 
        isChartDisposed = true; 
        window.removeEventListener('resize', handleResize); 
        resizeObserver.disconnect();
        feed?.close();
        chart.remove(); 
        chartRef.current = null;
        candleSeriesRef.current = null;
        smaSeriesRef.current = null;
        emaSeriesRef.current = null;
        currentPriceLineRef.current = null;
    };
  }, [timeframe, dataSource, symbol, retryCount]);

  useEffect(() => {
     if (smaSeriesRef.current) smaSeriesRef.current.applyOptions({ visible: indicators.sma });
     if (emaSeriesRef.current) emaSeriesRef.current.applyOptions({ visible: indicators.ema });
  }, [indicators]);

  // --- Drawing Logic ---

  const getSnappedPrice = (cursorY: number, disableSnap: boolean): number | null => {
    if (!candleSeriesRef.current) return null;
    const rawPrice = candleSeriesRef.current.coordinateToPrice(cursorY as any);
    if (rawPrice === null) return null;

    if (!isSnapEnabled || disableSnap || !hoveredCandleRef.current) return rawPrice;

    const c = hoveredCandleRef.current;
    const candidates = [c.open, c.high, c.low, c.close];
    const threshold = 20;

    let bestPrice: number | null = rawPrice;
    let minDiff = Infinity;

    candidates.forEach(p => {
        const py = candleSeriesRef.current!.priceToCoordinate(p as BarPrice);
        if (py !== null) {
            const diff = Math.abs(py - cursorY);
            if (diff < threshold && diff < minDiff) {
                minDiff = diff;
                bestPrice = p;
            }
        }
    });

    return bestPrice;
  };

  // --- Drawing Logic Helpers ---
  const getDistToSegment = (px: number, py: number, x1: number, y1: number, x2: number, y2: number) => {
    const l2 = Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2);
    if (l2 === 0) return Math.sqrt(Math.pow(px - x1, 2) + Math.pow(py - y1, 2));
    let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
    t = Math.max(0, Math.min(1, t));
    return Math.sqrt(Math.pow(px - (x1 + t * (x2 - x1)), 2) + Math.pow(py - (y1 + t * (y2 - y1)), 2));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!chartRef.current || !candleSeriesRef.current) return;
    
    const rect = chartContainerRef.current!.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const price = candleSeriesRef.current.coordinateToPrice(y);
    const time = chartRef.current.timeScale().coordinateToTime(x);
    
    if (price === null || time === null) return;

    if (activeTool === 'horizontal') {
       candleSeriesRef.current.createPriceLine({
         price, color: '#3b82f6', lineWidth: 1, lineStyle: 0, axisLabelVisible: true, title: 'Level'
       });
       setActiveTool('cursor');
       return;
    }

    if (activeTool === 'cursor') {
       // Refined Hit-Testing for Overlapping Objects
       const timeScale = chartRef.current.timeScale();
       const series = candleSeriesRef.current;
       
       let closestId: string | null = null;
       let minDistance = 15; // Hit threshold in pixels

       drawings.forEach(d => {
         const x1 = timeScale.timeToCoordinate(d.p1.time);
         const y1 = series.priceToCoordinate(d.p1.price);
         const x2 = timeScale.timeToCoordinate(d.p2.time);
         const y2 = series.priceToCoordinate(d.p2.price);

         if (x1 !== null && y1 !== null && x2 !== null && y2 !== null) {
           const dist = getDistToSegment(x, y, x1, y1, x2, y2);
           if (dist < minDistance) {
             minDistance = dist;
             closestId = d.id;
           }
         }
       });

       if (closestId) {
         setSelectedDrawingId(closestId);
         setPanelPos({ x, y });
       } else {
         setSelectedDrawingId(null);
       }
       return;
    }

    // Drawing Start
    if (!tempDrawing) {
      const startPrice = getSnappedPrice(y, e.shiftKey) ?? price;
      setTempDrawing({ type: activeTool, p1: { time, price: startPrice }, p2: { time, price: startPrice } });
      setSelectedDrawingId(null); 
    } else {
      // Drawing End
      const endPrice = getSnappedPrice(y, e.shiftKey) ?? price;
      const newId = Date.now().toString();
      const newDrawing: DrawingObject = {
        id: newId,
        type: activeTool as 'trendline' | 'fib',
        p1: tempDrawing.p1!,
        p2: { time, price: endPrice },
        color: '#3b82f6',
        lineWidth: 2
      };
      setDrawings([...drawings, newDrawing]);
      setTempDrawing(null);
      setActiveTool('cursor');
      setSelectedDrawingId(newId);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!chartRef.current || !candleSeriesRef.current) return;
    
    const rect = chartContainerRef.current!.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const price = candleSeriesRef.current.coordinateToPrice(y);
    const time = chartRef.current.timeScale().coordinateToTime(x);
    
    if (price === null || time === null) return;

    const snappedPrice = getSnappedPrice(y, e.shiftKey) ?? price;

    if (dragHandle) {
      setDrawings(prev => prev.map(d => {
        if (d.id === dragHandle.id) {
          if (dragHandle.handle === 'sl' || dragHandle.handle === 'tp') {
              return { ...d, [dragHandle.handle]: price };
          }
          return { ...d, [dragHandle.handle]: { time, price: snappedPrice } };
        }
        return d;
      }));
      return;
    }

    if (tempDrawing) {
       setTempDrawing({ ...tempDrawing, p2: { time, price: snappedPrice } });
    }
  };

  const handleMouseUp = () => {
    setDragHandle(null);
  };

  // Triggered when clicking an SVG element directly
  const handleObjectClick = (e: React.MouseEvent, id: string) => {
     e.stopPropagation();
     if (activeTool === 'cursor') {
        setSelectedDrawingId(id);
        const rect = chartContainerRef.current!.getBoundingClientRect();
        setPanelPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
     }
  };

  const startDragHandle = (e: React.MouseEvent, id: string, handle: 'p1' | 'p2' | 'sl' | 'tp') => {
    e.stopPropagation();
    if (activeTool === 'cursor') {
       setSelectedDrawingId(id); 
       setDragHandle({ id, handle });
       const rect = chartContainerRef.current!.getBoundingClientRect();
       setPanelPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    }
  };

  const deleteDrawing = (id: string) => {
    setDrawings(prev => prev.filter(d => d.id !== id));
    if (selectedDrawingId === id) setSelectedDrawingId(null);
  };

  const updateDrawingProps = (id: string, props: Partial<DrawingObject>) => {
    setDrawings(prev => prev.map(d => d.id === id ? { ...d, ...props } : d));
  };

  // --- Broker / Trading Functions ---
  const handleConnectBroker = async () => { /* ... */ setBrokerConnected(true); };
  
  const handleTrade = async (side: 'Buy' | 'Sell') => {
      if (currentPrice <= 0) { showNotificationMsg("Waiting for price...", "error"); return; }
      const sl = slPrice ? parseFloat(slPrice) : undefined;
      const tp = tpPrice ? parseFloat(tpPrice) : undefined;
      setProcessingOrder(true);
      const response = await brokerService.placeOrder("NDX100", side, lotSize, currentPrice, tp, sl);
      setProcessingOrder(false);
      if (response.success && response.position) {
          setPositions(prev => [...prev, response.position!]);
          showNotificationMsg(`${side} Filled @ ${response.position.entryPrice.toFixed(2)}`);
          setSlPrice(''); setTpPrice('');
      } else { showNotificationMsg("Order Failed", "error"); }
  };
  const handleClosePosition = async (id: string) => { setPositions(prev => prev.filter(p => p.id !== id)); };

  // --- Render Helpers ---
  const renderPositions = () => {
     if (!chartRef.current || !candleSeriesRef.current) return null;
     const series = candleSeriesRef.current;
     return positions.map(pos => {
         const yEntry = series.priceToCoordinate(pos.entryPrice);
         const ySL = pos.sl ? series.priceToCoordinate(pos.sl) : null;
         const yTP = pos.tp ? series.priceToCoordinate(pos.tp) : null;
         return (
             <g key={pos.id} style={{ pointerEvents: 'none' }}>
                 {yEntry !== null && (<><line x1="0" y1={yEntry} x2="100%" y2={yEntry} stroke={pos.side === 'Buy' ? '#10b981' : '#ef4444'} strokeWidth="1" strokeDasharray="2,2" opacity="0.8" /><text x="10" y={yEntry - 5} fill={pos.side === 'Buy' ? '#10b981' : '#ef4444'} fontSize="10" fontWeight="bold">{pos.side} @ {pos.entryPrice.toFixed(2)}</text></>)}
                 {ySL !== null && (<><line x1="0" y1={ySL} x2="100%" y2={ySL} stroke="#ef4444" strokeWidth="1" strokeDasharray="4,2" /><text x="10" y={ySL - 5} fill="#ef4444" fontSize="10" fontWeight="bold">SL {pos.sl!.toFixed(2)}</text></>)}
                 {yTP !== null && (<><line x1="0" y1={yTP} x2="100%" y2={yTP} stroke="#10b981" strokeWidth="1" strokeDasharray="4,2" /><text x="10" y={yTP - 5} fill="#10b981" fontSize="10" fontWeight="bold">TP {pos.tp!.toFixed(2)}</text></>)}
             </g>
         );
     });
  };

  const renderDrawings = () => {
     if (!chartRef.current || !candleSeriesRef.current) return null;
     const timeScale = chartRef.current.timeScale();
     const series = candleSeriesRef.current;
     
     // Sort drawings to ensure selected and hovered ones are on top
     const allDrawings = [...drawings].sort((a, b) => {
        // Selected drawing always on top of everything
        if (a.id === selectedDrawingId) return 1;
        if (b.id === selectedDrawingId) return -1;
        // Hovered drawing on top of normal drawings
        if (a.id === hoveredDrawingId) return 1;
        if (b.id === hoveredDrawingId) return -1;
        return 0;
     });

     if (tempDrawing && tempDrawing.p1 && tempDrawing.p2) {
       allDrawings.push({ id: 'temp', type: tempDrawing.type as any, p1: tempDrawing.p1, p2: tempDrawing.p2, color: '#3b82f6' });
     }

     return allDrawings.map(d => {
        const x1 = timeScale.timeToCoordinate(d.p1.time);
        const y1 = series.priceToCoordinate(d.p1.price);
        const x2 = timeScale.timeToCoordinate(d.p2.time);
        const y2 = series.priceToCoordinate(d.p2.price);
        
        if (x1 === null || y1 === null || x2 === null || y2 === null) return null;
        
        const isSelected = selectedDrawingId === d.id;
        const isHovered = hoveredDrawingId === d.id;
        const color = d.color || '#3b82f6';
        
        // Render Hit Area (Thick transparent line) + Visible Line
        return (
          <g key={d.id} 
             onClick={(e) => handleObjectClick(e, d.id)} 
             onMouseEnter={() => setHoveredDrawingId(d.id)}
             onMouseLeave={() => setHoveredDrawingId(null)}
             style={{ pointerEvents: 'visibleStroke', cursor: activeTool === 'cursor' ? 'pointer' : 'crosshair' }}
          >
             {d.type === 'trendline' && (
                <>
                  {/* Invisible Hit Area for easier selection */}
                  <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="transparent" strokeWidth="20" />
                  
                  {/* Outer Glow / Hover Effect */}
                  {(isSelected || isHovered) && (
                    <line 
                      x1={x1} y1={y1} x2={x2} y2={y2} 
                      stroke={color} 
                      strokeWidth={isSelected ? (isHovered ? 12 : 10) : 8} 
                      opacity={isSelected ? (isHovered ? 0.4 : 0.25) : 0.15} 
                      className="transition-all duration-300"
                    />
                  )}
                  
                  {/* Visible Line */}
                  <line 
                    x1={x1} y1={y1} x2={x2} y2={y2} 
                    stroke={color} 
                    strokeWidth={isSelected ? 3 : 2} 
                    opacity={isSelected ? 1 : (isHovered ? 0.9 : 0.7)} 
                    className="transition-all duration-200"
                  />
                </>
             )}
             
             {d.type === 'fib' && (
               <g>
                 <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="transparent" strokeWidth="20" />
                 
                 {/* Main Diagonal with Glow */}
                 {(isSelected || isHovered) && (
                    <line 
                      x1={x1} y1={y1} x2={x2} y2={y2} 
                      stroke={color} 
                      strokeWidth={isSelected ? 6 : 4} 
                      opacity={isSelected ? 0.3 : 0.2} 
                    />
                 )}
                 <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#ffffff" strokeDasharray="4,4" opacity={isSelected ? 1 : (isHovered ? 0.8 : 0.4)} />
                 
                 {[0, 0.5, 0.618, 1].map(level => {
                   const y = y1 + ((y2 - y1) * level);
                   const isKeyLevel = level === 0.618 || level === 0.5;
                   return (
                      <g key={level}>
                        {/* Level Line Glow */}
                        {(isSelected || isHovered) && (
                          <line 
                            x1={x1} y1={y} x2={x1 + 2000} y2={y} 
                            stroke={isKeyLevel ? '#facc15' : color} 
                            strokeWidth={isSelected ? 5 : 3} 
                            opacity={isSelected ? 0.2 : 0.1} 
                          />
                        )}
                        <line 
                          x1={x1} y1={y} x2={x1 + 2000} y2={y} 
                          stroke={isKeyLevel ? '#facc15' : color} 
                          strokeWidth={isKeyLevel ? 2 : 1} 
                          opacity={isSelected ? 1 : (isHovered ? 0.9 : 0.6)} 
                        />
                        <text x={x1 + 5} y={y - 5} fill="white" fontSize="10" fontWeight={isKeyLevel ? "bold" : "normal"} opacity={isSelected ? 1 : (isHovered ? 1 : 0.7)}>
                          {level === 0.618 ? '61.8% (Golden)' : level === 0.5 ? '50.0% (Equilibrium)' : level}
                        </text>
                      </g>
                   );
                 })}
               </g>
             )}

              {/* Handles - Only visible if selected */}
             {isSelected && (
               <>
                 {/* P1 Handle */}
                 <g className="cursor-grab active:cursor-grabbing" onMouseDown={(e) => startDragHandle(e, d.id, 'p1')}>
                    <circle cx={x1} cy={y1} r="8" fill="rgba(255,255,255,0.1)" stroke="none" />
                    <circle cx={x1} cy={y1} r="5" fill="white" stroke={color} strokeWidth="2" />
                 </g>
                 
                 {/* P2 Handle */}
                 <g className="cursor-grab active:cursor-grabbing" onMouseDown={(e) => startDragHandle(e, d.id, 'p2')}>
                    <circle cx={x2} cy={y2} r="8" fill="rgba(255,255,255,0.1)" stroke="none" />
                    <circle cx={x2} cy={y2} r="5" fill="white" stroke={color} strokeWidth="2" />
                 </g>
                 
                 {/* SL Handle & Line */}
                 {d.sl && series.priceToCoordinate(d.sl) !== null && (
                    <g className="cursor-ns-resize group/sl" onMouseDown={(e) => startDragHandle(e, d.id, 'sl')}>
                       <line x1="0" y1={series.priceToCoordinate(d.sl)!} x2="100%" y2={series.priceToCoordinate(d.sl)!} stroke="transparent" strokeWidth="10" />
                       <line x1="0" y1={series.priceToCoordinate(d.sl)!} x2="100%" y2={series.priceToCoordinate(d.sl)!} stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4,4" />
                       <rect x="10" y={series.priceToCoordinate(d.sl)! - 10} width="60" height="20" rx="4" fill="#ef4444" opacity="0.9" />
                       <text x="15" y={series.priceToCoordinate(d.sl)! + 4} fill="white" fontSize="10" fontWeight="bold">SL: {d.sl.toFixed(2)}</text>
                    </g>
                 )}
                 
                 {/* TP Handle & Line */}
                  {d.tp && series.priceToCoordinate(d.tp) !== null && (
                    <g className="cursor-ns-resize group/tp" onMouseDown={(e) => startDragHandle(e, d.id, 'tp')}>
                       <line x1="0" y1={series.priceToCoordinate(d.tp)!} x2="100%" y2={series.priceToCoordinate(d.tp)!} stroke="transparent" strokeWidth="10" />
                       <line x1="0" y1={series.priceToCoordinate(d.tp)!} x2="100%" y2={series.priceToCoordinate(d.tp)!} stroke="#10b981" strokeWidth="1.5" strokeDasharray="4,4" />
                       <rect x="10" y={series.priceToCoordinate(d.tp)! - 10} width="60" height="20" rx="4" fill="#10b981" opacity="0.9" />
                       <text x="15" y={series.priceToCoordinate(d.tp)! + 4} fill="white" fontSize="10" fontWeight="bold">TP: {d.tp.toFixed(2)}</text>
                    </g>
                 )}
               </>
             )}
          </g>
        );
     });
  };
  
  const renderICT = () => {
    if (!chartRef.current || !candleSeriesRef.current || !chartContainerRef.current) return null;
    const timeScale = chartRef.current.timeScale();
    const series = candleSeriesRef.current;
    const projectionWidth = 2000;

    return (
       <g style={{ pointerEvents: 'none' }}> 
         {showFvgs && fvgs.map(f => {
           const x = timeScale.timeToCoordinate(f.startTime as Time);
           const y1 = series.priceToCoordinate(f.top);
           const y2 = series.priceToCoordinate(f.bottom);
           if (x === null || y1 === null || y2 === null) return null;
           return (
             <g key={f.id}>
                <rect x={x} y={Math.min(y1, y2)} width={projectionWidth} height={Math.abs(y1 - y2)} fill={f.type === 'Bullish' ? 'rgba(34, 197, 94, 0.15)' : 'rgba(239, 68, 68, 0.15)'} />
             </g>
           );
         })}
         {showOrderBlocks && orderBlocks.map(ob => {
           const x = timeScale.timeToCoordinate(ob.startTime as Time);
           const y1 = series.priceToCoordinate(ob.top);
           const y2 = series.priceToCoordinate(ob.bottom);
           if (x === null || y1 === null || y2 === null) return null;
           return (
             <g key={ob.id}>
                <rect x={x} y={Math.min(y1, y2)} width={projectionWidth} height={Math.abs(y1 - y2)} fill="none" stroke={ob.type === 'Bullish' ? '#22c55e' : '#ef4444'} strokeWidth="1" strokeDasharray="2,2" />
             </g>
           );
         })}
         {showBreakers && breakerBlocks.map(bb => {
           const x = timeScale.timeToCoordinate(bb.startTime as Time);
           const y1 = series.priceToCoordinate(bb.top);
           const y2 = series.priceToCoordinate(bb.bottom);
           if (x === null || y1 === null || y2 === null) return null;
           
           const midY = (y1 + y2) / 2;
           const color = bb.type === 'Bullish' ? '#06b6d4' : '#f97316';
           const fillColor = bb.type === 'Bullish' ? 'rgba(6, 182, 212, 0.1)' : 'rgba(249, 115, 22, 0.1)';

           return (
             <g key={bb.id} opacity={bb.mitigated ? 0.3 : 1}>
                {/* Breaker Zone */}
                <rect 
                  x={x} y={Math.min(y1, y2)} 
                  width={projectionWidth} 
                  height={Math.abs(y1 - y2)} 
                  fill={fillColor} 
                  stroke={color} 
                  strokeWidth="1" 
                  strokeDasharray="4,2"
                />
                {/* Mean Threshold (50% Level) */}
                <line 
                  x1={x} y1={midY} 
                  x2={x + projectionWidth} y2={midY} 
                  stroke={color} 
                  strokeWidth="0.5" 
                  strokeDasharray="2,2" 
                  opacity="0.5"
                />
                {/* Label */}
                <rect 
                  x={x} y={Math.min(y1, y2) - 14} 
                  width={45} height={14} 
                  fill={color} 
                  opacity="0.8" 
                  rx="2"
                />
                <text x={x + 4} y={Math.min(y1, y2) - 4} fill="white" fontSize="8" fontWeight="bold">
                   {bb.type === 'Bullish' ? 'BULL BRK' : 'BEAR BRK'}
                </text>
             </g>
           );
         })}
       </g>
    );
  };
  
  const selectedDrawing = drawings.find(d => d.id === selectedDrawingId);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      
      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-2xl w-full max-w-md animate-fade-in">
             <div className="flex justify-between items-center mb-6">
               <h3 className="text-xl font-bold text-white flex items-center gap-2"><Globe className="w-5 h-5 text-primary"/> Data Feed</h3>
               <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-white"><X className="w-5 h-5"/></button>
             </div>
             <div className="space-y-6">
               <section>
                 <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                   <Globe className="w-3 h-3"/> Data Feed
                 </h4>
                 <div className="space-y-3">
                   <div>
                     <label className="text-[11px] text-gray-400 mb-1 block">Finnhub API Key</label>
                     <input 
                       type="password" 
                       value={finnhubKey} 
                       onChange={(e) => setFinnhubKey(e.target.value)} 
                       placeholder="Enter your API key..."
                       className="w-full bg-black/40 border border-white/10 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-primary outline-none transition-all" 
                     />
                   </div>
                   <div>
                     <label className="text-[11px] text-gray-400 mb-1 block">Trading Symbol</label>
                     <input 
                       type="text" 
                       value={symbol} 
                       onChange={(e) => setSymbol(e.target.value.toUpperCase())} 
                       placeholder="e.g. AAPL, BTC/USD"
                       className="w-full bg-black/40 border border-white/10 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-primary outline-none transition-all" 
                     />
                   </div>
                 </div>
               </section>

               <section>
                 <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                   <Activity className="w-3 h-3"/> Chart Studies
                 </h4>
                 <div className="grid grid-cols-2 gap-2">
                   {[
                     { label: 'Kill Zones', state: showKillZones, setter: setShowKillZones },
                     { label: 'Order Blocks', state: showOrderBlocks, setter: setShowOrderBlocks },
                     { label: 'Fair Value Gaps', state: showFvgs, setter: setShowFvgs },
                     { label: 'Breaker Blocks', state: showBreakers, setter: setShowBreakers },
                   ].map((item) => (
                     <button
                       key={item.label}
                       onClick={() => item.setter(!item.state)}
                       className={`flex items-center justify-between px-3 py-2 rounded-lg border transition-all ${
                         item.state 
                           ? 'bg-primary/10 border-primary/30 text-primary' 
                           : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10'
                       }`}
                     >
                       <span className="text-xs font-medium">{item.label}</span>
                       {item.state ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                     </button>
                   ))}
                 </div>
               </section>

               <button 
                 onClick={saveSettings} 
                 className="w-full py-3 bg-primary hover:bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-primary/20 transition-all active:scale-[0.98]"
               >
                 Apply Changes
               </button>
             </div>
          </div>
        </div>
      )}

      {/* Main Chart Area */}
      <div className="lg:col-span-3 bg-surface border border-white/10 rounded-xl p-6 shadow-lg relative flex flex-col h-[600px]">
        {/* Header Toolbar */}
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 shrink-0 gap-4">
           {/* ... Header Content (Same as before) ... */}
           <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-primary" />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">{dataSource === 'finnhub' ? symbol : 'NDX 100'}</h2>
                <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase tracking-wider ${
                  feedStatus === 'connected' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500' :
                  feedStatus === 'connecting' ? 'bg-amber-500/10 border-amber-500/30 text-amber-500 animate-pulse' :
                  feedStatus === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-500' :
                  'bg-gray-500/10 border-gray-500/30 text-gray-500'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    feedStatus === 'connected' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' :
                    feedStatus === 'connecting' ? 'bg-amber-500' :
                    feedStatus === 'error' ? 'bg-red-500' :
                    'bg-gray-500'
                  }`} />
                  {feedStatus}
                </div>
                
                {/* Bias Badge */}
                <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase tracking-wider ${
                  overallBias === 'Bullish' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500' :
                  overallBias === 'Bearish' ? 'bg-red-500/10 border-red-500/30 text-red-500' :
                  'bg-gray-500/10 border-gray-500/30 text-gray-500'
                }`}>
                  {overallBias === 'Bullish' ? <TrendingUp className="w-3 h-3" /> : overallBias === 'Bearish' ? <TrendingDown className="w-3 h-3" /> : <Activity className="w-3 h-3" />}
                  {overallBias} BIAS
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex bg-black/30 rounded-lg p-1 border border-white/10">
                <button onClick={() => setDataSource('mock')} className={`px-3 py-1 text-xs rounded ${dataSource === 'mock' ? 'bg-white/10 text-white' : 'text-gray-500'}`}><WifiOff className="w-3 h-3 inline mr-1"/> Sim</button>
                <button onClick={() => !finnhubKey ? setShowSettings(true) : setDataSource('finnhub')} className={`px-3 py-1 text-xs rounded ${dataSource === 'finnhub' ? 'bg-primary/20 text-primary' : 'text-gray-500'}`}><Wifi className="w-3 h-3 inline mr-1"/> Live</button>
             </div>
             <div className="relative group">
               <button className="p-2 bg-black/30 rounded-lg border border-white/10 hover:bg-white/5 text-gray-300 flex items-center gap-2 text-xs"><LineChart className="w-4 h-4" /> Study</button>
               <div className="absolute top-full right-0 mt-2 w-48 bg-surface border border-white/10 rounded-lg shadow-xl p-2 hidden group-hover:block z-50">
                 <div className="text-xs font-bold text-gray-500 mb-2 px-2">OVERLAYS</div>
                 <button onClick={() => setIndicators(p => ({...p, sma: !p.sma}))} className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex justify-between items-center text-gray-300"><span>SMA 20</span> {indicators.sma && <Eye className="w-3 h-3 text-primary"/>}</button>
                 <button onClick={() => setIndicators(p => ({...p, ema: !p.ema}))} className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex justify-between items-center text-gray-300"><span>EMA 50</span> {indicators.ema && <Eye className="w-3 h-3 text-primary"/>}</button>
                 <div className="h-px bg-white/10 my-2"></div>
                 <div className="text-xs font-bold text-gray-500 mb-2 px-2">ICT CONCEPTS</div>
                 <button onClick={() => { const next = !showFvgs; setShowFvgs(next); localStorage.setItem('show_fvgs', next.toString()); }} className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex justify-between items-center text-gray-300"><span>Fair Value Gaps</span> {showFvgs && <Eye className="w-3 h-3 text-primary"/>}</button>
                 <button onClick={() => { const next = !showOrderBlocks; setShowOrderBlocks(next); localStorage.setItem('show_orderblocks', next.toString()); }} className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex justify-between items-center text-gray-300"><span>Order Blocks</span> {showOrderBlocks && <Eye className="w-3 h-3 text-primary"/>}</button>
                 <button onClick={() => { const next = !showBreakers; setShowBreakers(next); localStorage.setItem('show_breakers', next.toString()); }} className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex justify-between items-center text-gray-300"><span>Breaker Blocks</span> {showBreakers && <Eye className="w-3 h-3 text-primary"/>}</button>
               </div>
             </div>
             <div className="flex bg-black/30 rounded-lg p-1 border border-white/10">
              {TIMEFRAMES.map((tf) => (<button key={tf} onClick={() => setTimeframe(tf)} className={`px-3 py-1 rounded text-xs font-medium transition-all ${timeframe === tf ? 'bg-primary text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}>{tf}</button>))}
            </div>
            <button onClick={() => setShowSettings(true)} className="p-2 text-gray-400 hover:text-white bg-black/30 rounded-lg border border-white/10"><Settings className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Chart Container */}
        <div className="flex-grow relative flex border border-white/10 rounded-lg overflow-hidden bg-[#18181b]">
          
          {/* Feed Status Overlay */}
          {feedStatus !== 'connected' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/40 backdrop-blur-[2px]">
              <div className="bg-[#18181b] border border-white/10 rounded-xl p-6 shadow-2xl flex flex-col items-center gap-4 max-w-xs text-center animate-in fade-in zoom-in duration-300">
                {feedStatus === 'connecting' && (
                  <>
                    <div className="w-10 h-10 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
                    <div>
                      <h4 className="text-white font-bold mb-1">Connecting to Feed</h4>
                      <p className="text-xs text-gray-400">Fetching market data for {symbol}...</p>
                    </div>
                  </>
                )}
                {feedStatus === 'error' && (
                  <>
                    <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center">
                      <ShieldAlert className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h4 className="text-white font-bold mb-1">Connection Error</h4>
                      <p className="text-xs text-red-400/80 mb-4 leading-relaxed">{feedError}</p>
                      <div className="flex gap-2 justify-center">
                        <button 
                          onClick={() => setRetryCount(prev => prev + 1)}
                          className="px-4 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/30 rounded-lg text-xs text-primary transition-colors font-bold"
                        >
                          Retry Connection
                        </button>
                        <button 
                          onClick={() => setDataSource('mock')}
                          className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs text-white transition-colors"
                        >
                          Simulator
                        </button>
                      </div>
                    </div>
                  </>
                )}
                {feedStatus === 'idle' && (
                  <p className="text-xs text-gray-500">Initializing chart...</p>
                )}
              </div>
            </div>
          )}

          {/* Left Toolbar */}
          <div className="w-14 bg-surface border-r border-white/10 flex flex-col items-center py-4 gap-3 z-20">
             <ToolbarButton active={activeTool === 'cursor'} onClick={() => setActiveTool('cursor')} icon={MousePointer2} label="Cursor" />
             <ToolbarButton active={activeTool === 'trendline'} onClick={() => setActiveTool('trendline')} icon={PenTool} label="Trendline" />
             <ToolbarButton active={activeTool === 'fib'} onClick={() => setActiveTool('fib')} icon={Percent} label="Fibonacci" />
             <ToolbarButton active={activeTool === 'horizontal'} onClick={() => setActiveTool('horizontal')} icon={Minus} label="Horizontal" />
             <div className="h-px w-8 bg-white/10 my-1"></div>
             <button onClick={() => setIsSnapEnabled(!isSnapEnabled)} className={`p-2 rounded-lg transition-colors group relative ${isSnapEnabled ? 'text-primary bg-primary/20' : 'text-gray-500 hover:text-white'}`}>
                <Magnet className="w-5 h-5" />
                 <div className="absolute left-full top-1/2 -translate-y-1/2 ml-3 px-3 py-1.5 bg-[#09090b] border border-white/20 rounded-lg text-[11px] font-semibold text-white opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none whitespace-nowrap z-50">Magnet Mode {isSnapEnabled ? '(On)' : '(Off)'}</div>
             </button>
             <div className="h-px w-8 bg-white/10 my-1"></div>
             <ToolbarButton onClick={() => setDrawings([])} icon={Eraser} label="Clear All" danger={true} />
          </div>

          <div className="flex-grow relative" ref={chartContainerRef}>
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] z-10 select-none overflow-hidden">
              <div className="flex flex-col items-center rotate-[-30deg]">
                <Zap className="w-64 h-64 fill-white" />
                <span className="text-8xl font-black tracking-tighter uppercase">Tecrypto</span>
              </div>
            </div>

             {/* Interaction Overlay: Visible only when drawing to capture clicks everywhere */}
             {activeTool !== 'cursor' && (
                <div 
                   className="absolute inset-0 z-30 cursor-crosshair"
                   onMouseDown={handleMouseDown}
                   onMouseMove={handleMouseMove}
                   onMouseUp={handleMouseUp}
                   onMouseLeave={handleMouseUp}
                />
             )}

            {/* Selected Drawing Properties */}
            {selectedDrawing && activeTool === 'cursor' && panelPos && (
              <div 
                 className="absolute z-40 bg-surface/95 backdrop-blur-md border border-white/20 rounded-xl p-3 shadow-2xl flex flex-col gap-3 animate-fade-in w-52"
                 style={{ 
                    left: Math.min(Math.max(10, panelPos.x + 20), (chartContainerRef.current?.clientWidth || 0) - 220),
                    top: Math.min(Math.max(10, panelPos.y - 100), (chartContainerRef.current?.clientHeight || 0) - 180)
                 }}
                 onMouseDown={(e) => e.stopPropagation()} 
              >
                 <div className="flex justify-between items-center border-b border-white/10 pb-2">
                   <span className="text-xs font-bold text-white flex items-center gap-1"><Sliders className="w-3 h-3"/> Properties</span>
                   <button onClick={() => deleteDrawing(selectedDrawing.id)} className="text-gray-400 hover:text-red-400"><Trash2 className="w-3 h-3"/></button>
                 </div>
                 
                 <div className="space-y-2">
                    {/* Line Color Picker */}
                    <div className="flex items-center justify-between">
                       <span className="text-[10px] text-gray-400">Color</span>
                       <div className="flex gap-1">
                          {['#3b82f6', '#10b981', '#ef4444', '#f59e0b', '#ffffff'].map(c => (
                            <button 
                              key={c}
                              onClick={() => updateDrawingProps(selectedDrawing.id, { color: c })}
                              className={`w-4 h-4 rounded-full border border-white/20 ${selectedDrawing.color === c ? 'ring-2 ring-white' : ''}`}
                              style={{ backgroundColor: c }}
                            />
                          ))}
                       </div>
                    </div>

                    <div className="flex items-center justify-between">
                       <span className="text-[10px] text-gray-400">Stop Loss</span>
                       {!selectedDrawing.sl ? (
                         <button onClick={() => updateDrawingProps(selectedDrawing.id, { sl: selectedDrawing.p1.price * 0.99 })} className="text-[10px] text-primary hover:underline">+ Add</button>
                       ) : (
                         <div className="flex items-center gap-1">
                            <input type="number" className="w-16 bg-black/20 border border-white/10 rounded px-1 py-0.5 text-[10px] text-white" value={selectedDrawing.sl.toFixed(2)} onChange={(e) => updateDrawingProps(selectedDrawing.id, { sl: parseFloat(e.target.value) })} />
                            <button onClick={() => updateDrawingProps(selectedDrawing.id, { sl: undefined })} className="text-gray-500 hover:text-red-400"><X className="w-3 h-3"/></button>
                         </div>
                       )}
                    </div>
                    <div className="flex items-center justify-between">
                       <span className="text-[10px] text-gray-400">Take Profit</span>
                       {!selectedDrawing.tp ? (
                         <button onClick={() => updateDrawingProps(selectedDrawing.id, { tp: selectedDrawing.p1.price * 1.01 })} className="text-[10px] text-primary hover:underline">+ Add</button>
                       ) : (
                         <div className="flex items-center gap-1">
                            <input type="number" className="w-16 bg-black/20 border border-white/10 rounded px-1 py-0.5 text-[10px] text-white" value={selectedDrawing.tp.toFixed(2)} onChange={(e) => updateDrawingProps(selectedDrawing.id, { tp: parseFloat(e.target.value) })} />
                            <button onClick={() => updateDrawingProps(selectedDrawing.id, { tp: undefined })} className="text-gray-500 hover:text-red-400"><X className="w-3 h-3"/></button>
                         </div>
                       )}
                    </div>
                 </div>
              </div>
            )}

            {/* SVG Overlay: pointer-events-none so chart is interactive, but children have pointer-events-auto */}
            <svg 
              ref={svgRef}
              className="absolute inset-0 z-20 w-full h-full overflow-hidden"
              style={{ pointerEvents: 'none' }} 
              onMouseMove={handleMouseMove} // Handle move for drag even if SVG is transparent (captured by overlay or chart bubble?)
              onMouseUp={handleMouseUp}
            >
              {renderICT()}
              {renderPositions()}
              {renderDrawings()}
            </svg>
            
            {notification && <div className={`absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded shadow-lg border animate-fade-in flex items-center gap-2 ${notification.type === 'success' ? 'bg-green-500/20 border-green-500/50 text-green-200' : 'bg-red-500/20 border-red-500/50 text-red-200'}`}><span className="text-sm font-medium">{notification.message}</span></div>}
          </div>
        </div>
      </div>

      {/* Trading Panel */}
      <div className="lg:col-span-1 space-y-4 h-[600px] flex flex-col">
        
        {/* Market Narrative & MTF Bias */}
        <div className="bg-surface border border-white/10 rounded-xl p-4 shadow-lg flex flex-col gap-3 shrink-0">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" /> 
              Market Narrative
            </h3>
            {isAnalyzing && <div className="w-3 h-3 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>}
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            {['1h', '15m', '5m'].map(tf => {
              const analysis = mtfAnalyses[tf];
              return (
                <div key={tf} className="bg-black/20 border border-white/5 rounded-lg p-2 flex flex-col items-center gap-1">
                  <span className="text-[10px] text-gray-500 font-bold uppercase">{tf}</span>
                  {analysis ? (
                    <span className={`text-[10px] font-black ${
                      analysis.bias === 'Bullish' ? 'text-emerald-500' : 
                      analysis.bias === 'Bearish' ? 'text-red-500' : 
                      'text-gray-400'
                    }`}>
                      {analysis.bias === 'Bullish' ? 'BULL' : analysis.bias === 'Bearish' ? 'BEAR' : 'NEUT'}
                    </span>
                  ) : (
                    <span className="text-[10px] text-gray-600">...</span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="bg-black/30 border border-white/5 rounded-lg p-3">
            <p className="text-[11px] text-gray-300 leading-relaxed italic">
              {narrative || "Analyzing market structure and timeframe alignment..."}
            </p>
          </div>
        </div>

        {!brokerConnected ? (
          <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-lg flex flex-col items-center justify-center text-center flex-grow">
            <ShieldAlert className="w-12 h-12 text-gray-500 mb-4" /><h3 className="text-lg font-bold text-white mb-2">Broker Disconnected</h3>
            <button onClick={handleConnectBroker} className="w-full py-3 bg-primary hover:bg-emerald-600 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-2"><Zap className="w-4 h-4" />Connect Pepperstone</button>
          </div>
        ) : (
          <>
            <div className="bg-surface border border-white/10 rounded-xl p-4 shadow-lg shrink-0">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs text-gray-400 uppercase">Equity</span>
                <span className="text-lg font-mono font-bold text-white">
                    ${(50000 + positions.reduce((sum, p) => sum + brokerService.calculateFloatingPnL(p, currentPrice), 0)).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                </span>
              </div>
            </div>
            
            <div className="bg-surface border border-white/10 rounded-xl p-4 shadow-lg flex flex-col gap-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2"><Target className="w-4 h-4 text-secondary" />Order Entry</h3>
              <div className="space-y-3">
                <div><label className="block text-[10px] text-gray-500 mb-1">Lot Size</label><input type="number" step="0.01" value={lotSize} onChange={(e) => setLotSize(parseFloat(e.target.value))} className="w-full bg-black/20 border border-white/10 rounded px-2 py-1 text-sm text-white" /></div>
                <div className="grid grid-cols-2 gap-2">
                    <div>
                        <label className="block text-[10px] text-gray-500 mb-1">Stop Loss</label>
                        <input type="number" value={slPrice} onChange={e => setSlPrice(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded px-2 py-1 text-sm text-white" placeholder="Price" />
                    </div>
                    <div>
                        <label className="block text-[10px] text-gray-500 mb-1">Take Profit</label>
                        <input type="number" value={tpPrice} onChange={e => setTpPrice(e.target.value)} className="w-full bg-black/20 border border-white/10 rounded px-2 py-1 text-sm text-white" placeholder="Price" />
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button disabled={processingOrder} onClick={() => handleTrade('Buy')} className="py-2.5 bg-green-600 hover:bg-green-500 text-white font-bold rounded-lg transition-all active:scale-95 disabled:opacity-50"><TrendingUp className="w-5 h-5 mx-auto" />BUY</button>
                  <button disabled={processingOrder} onClick={() => handleTrade('Sell')} className="py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg transition-all active:scale-95 disabled:opacity-50"><TrendingDown className="w-5 h-5 mx-auto" />SELL</button>
                </div>
              </div>
            </div>

            <div className="bg-surface border border-white/10 rounded-xl p-4 shadow-lg flex-grow overflow-hidden flex flex-col">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2 shrink-0"><Layers className="w-4 h-4 text-accent" />Positions</h3>
              <div className="overflow-y-auto space-y-2 flex-grow pr-1">
                {positions.map(pos => {
                   const pnl = brokerService.calculateFloatingPnL(pos, currentPrice);
                   const isWin = pnl > 0;
                   const isLoss = pnl < 0;
                   return (
                      <div key={pos.id} className="bg-white/5 border border-white/5 rounded-lg p-2 animate-fade-in">
                        <div className="flex justify-between items-center mb-1">
                            <span className={`text-[10px] font-bold px-1 rounded ${pos.side === 'Buy' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{pos.side}</span>
                            <button onClick={() => handleClosePosition(pos.id)} className="text-gray-500 hover:text-red-400 transition-colors"><XCircle className="w-4 h-4" /></button>
                        </div>
                        <div className="flex justify-between text-xs font-mono">
                            <span className="text-gray-400">{pos.size} Lots @ {pos.entryPrice.toFixed(1)}</span>
                            <span className={`font-bold ${isWin ? 'text-green-400' : isLoss ? 'text-red-400' : 'text-gray-400'}`}>
                                {currentPrice > 0 ? `$${pnl.toFixed(2)}` : '...'}
                            </span>
                        </div>
                      </div>
                   );
                })}
                {positions.length === 0 && <div className="text-center text-gray-500 text-xs italic py-4">No open positions</div>}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default LiveChart;
