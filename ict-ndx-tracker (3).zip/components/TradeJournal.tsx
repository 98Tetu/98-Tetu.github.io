
import React, { useState, useEffect } from 'react';
import { TradeEntry, ICTConcept, ChartAnalysisResult } from '../types';
import { AVAILABLE_CONCEPTS } from '../constants';
import { BookOpen, Plus, Trash2, Tag, Wand2, Calendar, Target, LogOut, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, orderBy, onSnapshot, addDoc, deleteDoc, doc, Timestamp, serverTimestamp } from 'firebase/firestore';

interface TradeJournalProps {
  latestAnalysis?: ChartAnalysisResult | null;
}

const TradeJournal: React.FC<TradeJournalProps> = ({ latestAnalysis }) => {
  const [trades, setTrades] = useState<TradeEntry[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  // Form State
  const [pair, setPair] = useState('NDX');
  const [direction, setDirection] = useState<'Long' | 'Short'>('Long');
  const [result, setResult] = useState<'Win' | 'Loss' | 'BE'>('Win');
  const [selectedConcepts, setSelectedConcepts] = useState<ICTConcept[]>([]);
  const [notes, setNotes] = useState('');
  const [entryPrice, setEntryPrice] = useState<string>('');
  const [exitPrice, setExitPrice] = useState<string>('');
  const [tradeDate, setTradeDate] = useState<string>(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    if (!auth.currentUser) return;

    const tradesRef = collection(db, 'users', auth.currentUser.uid, 'trades');
    const q = query(tradesRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const tradesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as TradeEntry[];
      setTrades(tradesData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${auth.currentUser?.uid}/trades`);
    });

    return () => unsubscribe();
  }, []);

  const toggleConcept = (concept: ICTConcept) => {
    if (selectedConcepts.includes(concept)) {
      setSelectedConcepts(selectedConcepts.filter(c => c !== concept));
    } else {
      setSelectedConcepts([...selectedConcepts, concept]);
    }
  };

  const toggleAddTrade = () => {
    if (!isAdding) {
      // Opening the form: Check for analysis data to auto-fill
      setIsAdding(true);
      
      if (latestAnalysis) {
        // Map detected concepts from strings to Enum
        const mappedConcepts: ICTConcept[] = [];
        const detected = latestAnalysis.detectedConcepts || [];

        detected.forEach(d => {
          const lower = d.toLowerCase();
          if (lower.includes('fvg') || lower.includes('fair value gap')) mappedConcepts.push(ICTConcept.FVG);
          if (lower.includes('order block') || lower.includes('ob')) mappedConcepts.push(ICTConcept.OB);
          if (lower.includes('breaker')) mappedConcepts.push(ICTConcept.Breaker);
          if (lower.includes('liquidity')) mappedConcepts.push(ICTConcept.LiquiditySweep);
          if (lower.includes('mss') || lower.includes('market structure shift')) mappedConcepts.push(ICTConcept.MSS);
          if (lower.includes('ote') || lower.includes('optimal trade entry')) mappedConcepts.push(ICTConcept.OTE);
        });
        
        const unique = [...new Set(mappedConcepts)];
        setSelectedConcepts(unique);

        // Pre-fill price levels
        if (latestAnalysis.suggestedEntry) setEntryPrice(latestAnalysis.suggestedEntry.toString());
        if (latestAnalysis.suggestedExit) setExitPrice(latestAnalysis.suggestedExit.toString());

        // Set direction based on trend analysis
        if (latestAnalysis.marketStructure?.trend === 'Bullish') setDirection('Long');
        else if (latestAnalysis.marketStructure?.trend === 'Bearish') setDirection('Short');

        // Compile intelligent notes
        let compiledNotes = '';
        if (latestAnalysis.analysis) compiledNotes += `AI Narrative: ${latestAnalysis.analysis}\n`;
        if (latestAnalysis.marketStructure?.points && latestAnalysis.marketStructure.points.length > 0) {
          compiledNotes += `\nMarket Structure: ${latestAnalysis.marketStructure.points.join(', ')}`;
        }
        setNotes(compiledNotes.trim());

      } else {
        // Reset if no analysis to ensure clean slate
        setSelectedConcepts([]);
        setNotes('');
        setEntryPrice('');
        setExitPrice('');
        setTradeDate(new Date().toISOString().split('T')[0]);
      }
    } else {
      setIsAdding(false);
    }
  };

  const handleAddTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    setSubmitting(true);
    try {
      const tradesRef = collection(db, 'users', auth.currentUser.uid, 'trades');
      await addDoc(tradesRef, {
        userId: auth.currentUser.uid,
        date: Timestamp.fromDate(new Date(tradeDate)),
        pair,
        direction,
        entryPrice: parseFloat(entryPrice) || 0,
        exitPrice: parseFloat(exitPrice) || 0,
        result,
        concepts: selectedConcepts,
        notes,
        createdAt: serverTimestamp()
      });

      setIsAdding(false);
      // Reset form
      setSelectedConcepts([]);
      setNotes('');
      setEntryPrice('');
      setExitPrice('');
      setTradeDate(new Date().toISOString().split('T')[0]);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${auth.currentUser.uid}/trades`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!auth.currentUser) return;
    
    try {
      const tradeRef = doc(db, 'users', auth.currentUser.uid, 'trades', id);
      await deleteDoc(tradeRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${auth.currentUser.uid}/trades/${id}`);
    }
  };

  return (
    <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-lg h-full overflow-hidden flex flex-col">
      <div className="flex items-center justify-between mb-6 shrink-0">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-500" />
          Trade Journal
        </h2>
        <button
          onClick={toggleAddTrade}
          className="p-2 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500 hover:text-white rounded-lg transition-colors flex items-center gap-2"
        >
           {isAdding ? 'Cancel' : <><Plus className="w-5 h-5" /></>}
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleAddTrade} className="mb-6 p-4 bg-white/5 rounded-lg border border-white/10 shrink-0 animate-fade-in overflow-y-auto max-h-[450px]">
          {latestAnalysis && (
            <div className="mb-3 flex items-center gap-2 text-xs text-accent">
              <Wand2 className="w-3 h-3" />
              <span>Auto-filled from AI Analysis</span>
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-4 mb-4">
             <div>
               <label className="block text-xs text-gray-500 mb-1">Date</label>
               <div className="relative">
                 <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                 <input 
                   type="date" 
                   value={tradeDate} 
                   onChange={e => setTradeDate(e.target.value)}
                   className="w-full bg-black/20 border border-white/10 rounded pl-9 pr-3 py-2 text-sm text-white focus:border-indigo-500 outline-none appearance-none"
                 />
               </div>
             </div>
             <div>
               <label className="block text-xs text-gray-500 mb-1">Pair</label>
               <input 
                 type="text" 
                 value={pair} 
                 onChange={e => setPair(e.target.value)}
                 className="w-full bg-black/20 border border-white/10 rounded px-3 py-2 text-sm text-white focus:border-indigo-500 outline-none"
               />
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
             <div>
               <label className="block text-xs text-gray-500 mb-1">Direction</label>
               <select 
                 value={direction}
                 onChange={e => setDirection(e.target.value as any)}
                 className="w-full bg-black/20 border border-white/10 rounded px-3 py-2 text-sm text-white focus:border-indigo-500 outline-none"
               >
                 <option value="Long">Long</option>
                 <option value="Short">Short</option>
               </select>
             </div>
             <div>
               <label className="block text-xs text-gray-500 mb-1">Result</label>
               <select 
                 value={result}
                 onChange={e => setResult(e.target.value as any)}
                 className="w-full bg-black/20 border border-white/10 rounded px-3 py-2 text-sm text-white focus:border-indigo-500 outline-none"
               >
                 <option value="Win">Win</option>
                 <option value="Loss">Loss</option>
                 <option value="BE">Break Even</option>
               </select>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
             <div>
               <label className="block text-xs text-gray-500 mb-1">Entry Price</label>
               <div className="relative">
                 <Target className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                 <input 
                   type="number" 
                   step="0.01"
                   value={entryPrice} 
                   onChange={e => setEntryPrice(e.target.value)}
                   className="w-full bg-black/20 border border-white/10 rounded pl-9 pr-3 py-2 text-sm text-white focus:border-indigo-500 outline-none"
                   placeholder="18250.00"
                 />
               </div>
             </div>
             <div>
               <label className="block text-xs text-gray-500 mb-1">Exit Price</label>
               <div className="relative">
                 <LogOut className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                 <input 
                   type="number" 
                   step="0.01"
                   value={exitPrice} 
                   onChange={e => setExitPrice(e.target.value)}
                   className="w-full bg-black/20 border border-white/10 rounded pl-9 pr-3 py-2 text-sm text-white focus:border-indigo-500 outline-none"
                   placeholder="18300.00"
                 />
               </div>
             </div>
          </div>
          
          <div className="mb-4">
             <label className="block text-xs text-gray-500 mb-1">Confluences (Concepts)</label>
             <div className="flex flex-wrap gap-2">
               {AVAILABLE_CONCEPTS.map(c => (
                 <button
                   key={c}
                   type="button"
                   onClick={() => toggleConcept(c)}
                   className={`text-xs px-2 py-1 rounded border transition-colors ${
                     selectedConcepts.includes(c) 
                       ? 'bg-indigo-500 border-indigo-500 text-white' 
                       : 'bg-transparent border-white/20 text-gray-400 hover:border-white/40'
                   }`}
                 >
                   {c}
                 </button>
               ))}
             </div>
          </div>

          <div className="mb-4">
             <label className="block text-xs text-gray-500 mb-1">Notes</label>
             <textarea 
               value={notes}
               onChange={e => setNotes(e.target.value)}
               className="w-full bg-black/20 border border-white/10 rounded px-3 py-2 text-sm text-white focus:border-indigo-500 outline-none h-20 resize-none"
               placeholder="What was the setup?..."
             />
          </div>

          <button 
            type="submit" 
            disabled={submitting}
            className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded font-medium text-sm transition-colors shadow-lg flex items-center justify-center gap-2"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Log Trade'}
          </button>
        </form>
      )}

      <div className="overflow-y-auto space-y-3 pr-2 flex-grow">
        {loading ? (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
          </div>
        ) : trades.length === 0 ? (
          <div className="text-center text-gray-500 py-10 italic text-sm">No trades recorded yet.</div>
        ) : (
          trades.map(trade => (
            <div key={trade.id} className="p-3 bg-white/5 rounded-lg border border-white/5 hover:border-white/10 transition-colors group">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${trade.result === 'Win' ? 'bg-green-500/20 text-green-400' : trade.result === 'Loss' ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'}`}>
                    {trade.result}
                  </span>
                  <span className="font-mono font-bold text-white text-xs">{trade.pair}</span>
                  <span className="text-[10px] text-gray-500 font-mono">
                    {trade.date instanceof Timestamp ? format(trade.date.toDate(), 'MMM dd') : format(new Date(trade.date), 'MMM dd')}
                  </span>
                </div>
                <button onClick={() => handleDelete(trade.id)} className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-2">
                <div className="text-[10px] text-gray-500">
                  <span className="block text-gray-600">Entry / Exit</span>
                  <span className="font-mono text-gray-300">{trade.entryPrice.toFixed(2)} / {trade.exitPrice.toFixed(2)}</span>
                </div>
                <div className="text-right text-[10px]">
                  <span className={`font-bold ${trade.direction === 'Long' ? 'text-green-400' : 'text-red-400'}`}>{trade.direction.toUpperCase()}</span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-1 mb-2">
                {trade.concepts.map((c, i) => (
                  <span key={i} className="text-[10px] text-gray-400 bg-black/30 px-1.5 rounded flex items-center gap-1">
                    <Tag className="w-3 h-3" /> {c}
                  </span>
                ))}
              </div>
              
              <p className="text-xs text-gray-400 line-clamp-2 italic">{trade.notes}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default TradeJournal;
