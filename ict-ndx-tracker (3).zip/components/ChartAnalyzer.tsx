
import React, { useState, useRef } from 'react';
import { analyzeChartImage } from '../services/geminiService';
import { ChartAnalysisResult } from '../types';
import { Upload, ScanLine, X, ImageIcon, CheckCircle, TrendingUp, TrendingDown, Minus, Activity, Star } from 'lucide-react';
import Pricing from './Pricing';

interface ChartAnalyzerProps {
  onAnalysisComplete?: (result: ChartAnalysisResult) => void;
  isPremium?: boolean;
}

const ChartAnalyzer: React.FC<ChartAnalyzerProps> = ({ onAnalysisComplete, isPremium }) => {
  const [image, setImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ChartAnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [isPricingOpen, setIsPricingOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        // Remove data URL prefix for API if needed, but Gemini SDK often handles clean base64. 
        // The example shows passing pure base64 data, so we strip the prefix.
        const base64Data = base64String.split(',')[1];
        setImage(base64Data);
        setAnalysis(null); // Reset previous analysis
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const result = await analyzeChartImage(image);
      setAnalysis(result);
      if (onAnalysisComplete) {
        onAnalysisComplete(result);
      }
    } catch (error) {
      console.error(error);
      alert("Failed to analyze image");
    } finally {
      setLoading(false);
    }
  };

  const clearImage = () => {
    setImage(null);
    setAnalysis(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <ScanLine className="w-5 h-5 text-accent" />
          AI Chart Setup Analyzer
        </h2>
      </div>

      <div className="space-y-6 relative">
        {!isPremium && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md rounded-xl border border-white/10 p-6 text-center">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
              <Star className="w-8 h-8 text-primary fill-primary" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Premium Feature</h3>
            <p className="text-sm text-zinc-400 max-w-xs mb-6">
              AI-powered chart analysis is a premium feature. Upgrade to Tecrypto Elite to unlock.
            </p>
            <button 
              onClick={() => setIsPricingOpen(true)}
              className="px-8 py-3 bg-primary hover:bg-emerald-600 text-white font-bold rounded-xl transition-all shadow-lg shadow-primary/20 active:scale-95"
            >
              Unlock Now
            </button>
            <Pricing isOpen={isPricingOpen} onClose={() => setIsPricingOpen(false)} />
          </div>
        )}

        {!image ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-white/20 rounded-xl p-10 flex flex-col items-center justify-center cursor-pointer hover:bg-white/5 hover:border-accent/50 transition-all group"
          >
            <div className="p-4 bg-white/5 rounded-full group-hover:bg-accent/20 transition-colors mb-4">
              <Upload className="w-8 h-8 text-gray-400 group-hover:text-accent" />
            </div>
            <p className="text-gray-300 font-medium">Upload Chart Screenshot</p>
            <p className="text-sm text-gray-500 mt-2">Supports PNG, JPG. Analyzing market structure & ICT arrays.</p>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange}
            />
          </div>
        ) : (
          <div className="relative rounded-xl overflow-hidden bg-black border border-white/10">
            <img 
              src={`data:image/png;base64,${image}`} 
              alt="Chart Preview" 
              className="w-full h-64 object-contain opacity-80"
            />
            <button 
              onClick={clearImage}
              className="absolute top-2 right-2 p-1 bg-black/50 text-white rounded-full hover:bg-red-500/80 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            {!analysis && !loading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                 <button 
                   onClick={handleAnalyze}
                   className="px-6 py-3 bg-accent hover:bg-accent/80 text-white font-bold rounded-lg shadow-lg flex items-center gap-2 transition-transform hover:scale-105"
                 >
                   <ScanLine className="w-5 h-5" />
                   Run ICT Analysis
                 </button>
              </div>
            )}
            
            {loading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm">
                <div className="w-10 h-10 border-4 border-accent border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-white font-mono animate-pulse">Identifying FVG, OB, Liquidity...</p>
              </div>
            )}
          </div>
        )}

        {analysis && (
          <div className="animate-fade-in space-y-4">
            
            {/* Market Structure Section */}
            {analysis.marketStructure && (
              <div className="flex flex-col gap-3 p-4 bg-white/5 rounded-lg border border-white/10">
                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <span className="text-sm font-semibold text-gray-300 flex items-center gap-2">
                    <Activity className="w-4 h-4 text-primary" />
                    Market Structure
                  </span>
                  <div className={`flex items-center gap-2 px-2 py-1 rounded text-sm font-bold ${
                    analysis.marketStructure.trend === 'Bullish' ? 'bg-green-500/20 text-green-400' :
                    analysis.marketStructure.trend === 'Bearish' ? 'bg-red-500/20 text-red-400' :
                    'bg-gray-500/20 text-gray-400'
                  }`}>
                    {analysis.marketStructure.trend === 'Bullish' && <TrendingUp className="w-4 h-4" />}
                    {analysis.marketStructure.trend === 'Bearish' && <TrendingDown className="w-4 h-4" />}
                    {analysis.marketStructure.trend === 'Neutral' && <Minus className="w-4 h-4" />}
                    {analysis.marketStructure.trend}
                  </div>
                </div>
                
                {analysis.marketStructure.points.length > 0 ? (
                   <div className="flex flex-wrap gap-2">
                      {analysis.marketStructure.points.map((p, i) => (
                        <span key={i} className="text-xs font-mono bg-black/40 px-2 py-1 rounded text-gray-300 border border-white/5">
                          {p}
                        </span>
                      ))}
                   </div>
                ) : (
                  <span className="text-xs text-gray-500 italic">No specific structure points detected (e.g. HH, HL).</span>
                )}
              </div>
            )}

            {/* Concepts Tags */}
            <div className="flex flex-wrap gap-2">
               {analysis.detectedConcepts.map((tag, i) => (
                 <span key={i} className="px-3 py-1 bg-accent/20 text-accent text-xs font-bold rounded-full border border-accent/30 flex items-center gap-1">
                   <CheckCircle className="w-3 h-3" />
                   {tag}
                 </span>
               ))}
            </div>

            {/* Text Analysis */}
            <div className="prose prose-invert prose-sm max-w-none">
               <div className="p-4 bg-white/5 rounded-lg border border-white/10 text-gray-300 whitespace-pre-wrap leading-relaxed">
                 {analysis.analysis}
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChartAnalyzer;