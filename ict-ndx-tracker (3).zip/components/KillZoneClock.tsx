
import React, { useState, useEffect, useMemo } from 'react';
import { ICT_SESSIONS } from '../constants';
import { Clock, Moon, Sun, Briefcase, Globe } from 'lucide-react';
import { format } from 'date-fns';

const TIMEZONES = [
  { label: 'New York (EST/EDT)', value: 'America/New_York' },
  { label: 'London (GMT/BST)', value: 'Europe/London' },
  { label: 'Tokyo (JST)', value: 'Asia/Tokyo' },
  { label: 'Sydney (AEST/AEDT)', value: 'Australia/Sydney' },
  { label: 'UTC', value: 'UTC' },
  { label: 'Local Time', value: Intl.DateTimeFormat().resolvedOptions().timeZone },
];

const KillZoneClock: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedTz, setSelectedTz] = useState('America/New_York');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Format the current time for the large clock display
  const displayTimeStr = useMemo(() => {
    return currentTime.toLocaleTimeString('en-US', {
      timeZone: selectedTz,
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  }, [currentTime, selectedTz]);

  // To check if a session is active, we MUST compare against NY time 
  // because the session definitions are fixed to NY hours.
  const nyTimeStr = useMemo(() => {
    return currentTime.toLocaleTimeString('en-US', {
      timeZone: 'America/New_York',
      hour12: false,
      hour: '2-digit',
      minute: '2-digit'
    });
  }, [currentTime]);

  const activeSession = useMemo(() => {
    return ICT_SESSIONS.find(session => {
      const start = session.startLocal;
      const end = session.endLocal;
      // Handle sessions crossing midnight (like Asian range)
      if (start > end) {
        return nyTimeStr >= start || nyTimeStr < end;
      }
      return nyTimeStr >= start && nyTimeStr < end;
    });
  }, [nyTimeStr]);

  /**
   * Helper to convert a "HH:mm" string from NY Time to the Selected Timezone
   * This ensures the user sees the session times in their own timezone context.
   */
  const convertNYToSelectedTz = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    
    // Create a date object for "today" at the specified NY time
    const nyDate = new Date();
    // We use a specific formatting strategy to create a date anchored in NY
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
      hour12: false,
    });

    // To get the offset-correct date, we calculate how many ms away 
    // the target NY time is from the current NY time and apply it to a base date.
    // However, a simpler way is to just use the current day and set the hours in NY context.
    
    const parts = formatter.formatToParts(new Date());
    const nyYear = parseInt(parts.find(p => p.type === 'year')!.value);
    const nyMonth = parseInt(parts.find(p => p.type === 'month')!.value) - 1;
    const nyDay = parseInt(parts.find(p => p.type === 'day')!.value);

    // Create a string that Date.parse or constructor can handle as a specific TZ
    // Format: "YYYY-MM-DDTHH:mm:ss" in New York
    // This is tricky without a TZ library, so we use the Intl trick:
    const targetInNY = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
    targetInNY.setHours(hours, minutes, 0, 0);

    // Now convert that "NY time" back to the selected TZ
    return targetInNY.toLocaleTimeString('en-US', {
      timeZone: selectedTz,
      hour12: false,
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-surface border border-white/10 rounded-xl p-6 shadow-lg h-full flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-primary" />
          Market Sessions
        </h2>
        
        <div className="flex items-center gap-2 bg-black/30 border border-white/10 rounded-lg px-2 py-1">
          <Globe className="w-3.5 h-3.5 text-gray-500" />
          <select 
            value={selectedTz}
            onChange={(e) => setSelectedTz(e.target.value)}
            className="bg-transparent text-xs text-gray-300 outline-none cursor-pointer focus:text-white"
          >
            {TIMEZONES.map(tz => (
              <option key={tz.value} value={tz.value} className="bg-surface">
                {tz.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mb-6 p-4 bg-black/40 rounded-xl border border-white/5 flex items-center justify-between">
        <div>
          <div className="text-3xl font-mono font-bold text-white tracking-wider">
            {displayTimeStr}
          </div>
          <div className="text-[10px] text-muted uppercase tracking-widest mt-1 font-semibold">
            Current {selectedTz.split('/').pop()?.replace('_', ' ')} Time
          </div>
        </div>
        <div className="text-right">
           <div className="text-sm font-mono text-primary font-bold">
             {activeSession ? 'MARKET ACTIVE' : 'CONSOLIDATION'}
           </div>
           <div className="text-[10px] text-gray-500 italic">
             {activeSession ? activeSession.type : 'Wait for setup'}
           </div>
        </div>
      </div>

      <div className="space-y-3 overflow-y-auto pr-1">
        {ICT_SESSIONS.map((session) => {
          const isActive = activeSession?.name === session.name;
          const displayStart = convertNYToSelectedTz(session.startLocal);
          const displayEnd = convertNYToSelectedTz(session.endLocal);

          return (
            <div 
              key={session.name}
              className={`relative p-3 rounded-lg border transition-all duration-300 ${
                isActive 
                  ? 'bg-primary/10 border-primary shadow-[0_0_15px_rgba(16,185,129,0.1)]' 
                  : 'bg-white/5 border-white/5 hover:border-white/10'
              }`}
            >
              {isActive && (
                <div className="absolute top-3 right-3 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </div>
              )}
              
              <div className="flex justify-between items-center mb-1">
                <div className="flex items-center gap-2">
                  {session.type === 'Asian' && <Moon className="w-3.5 h-3.5 text-indigo-400" />}
                  {session.type === 'London' && <Briefcase className="w-3.5 h-3.5 text-amber-400" />}
                  {session.type === 'NewYork' && <Sun className="w-3.5 h-3.5 text-orange-400" />}
                  {session.type === 'Close' && <Clock className="w-3.5 h-3.5 text-purple-400" />}
                  <span className={`text-sm font-bold ${isActive ? 'text-primary' : 'text-gray-200'}`}>
                    {session.name}
                  </span>
                </div>
                <span className="font-mono text-[10px] text-gray-400 font-bold bg-black/40 px-1.5 py-0.5 rounded">
                  {displayStart} - {displayEnd}
                </span>
              </div>
              
              <p className="text-[10px] text-gray-500 leading-tight">{session.description}</p>
            </div>
          );
        })}
      </div>
      
      <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] text-gray-600 font-mono">
        <span>NY TIME: {nyTimeStr}</span>
        <span>{new Date().toLocaleDateString('en-US', { timeZone: selectedTz, month: 'short', day: 'numeric' })}</span>
      </div>
    </div>
  );
};

export default KillZoneClock;
