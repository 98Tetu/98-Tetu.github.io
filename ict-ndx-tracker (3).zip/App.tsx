import React, { useState, useEffect } from 'react';
import KillZoneClock from './components/KillZoneClock';
import MarketNarrative from './components/MarketNarrative';
import ChartAnalyzer from './components/ChartAnalyzer';
import TradeJournal from './components/TradeJournal';
import LiveChart from './components/LiveChart';
import Pricing from './components/Pricing';
import IctImageGenerator from './components/IctImageGenerator';
import ErrorBoundary from './components/ErrorBoundary';
import { BarChart2, Github, Zap, LogIn, LogOut, User as UserIcon, Phone, Mail, Globe, Star } from 'lucide-react';
import { ChartAnalysisResult } from './types';
import { auth, signInWithGoogle, logout, FirebaseUser, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';

const App: React.FC = () => {
  const [latestAnalysis, setLatestAnalysis] = useState<ChartAnalysisResult | null>(null);
  const [isPricingOpen, setIsPricingOpen] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
      
      if (currentUser) {
        // Ensure user profile exists in Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: currentUser.uid,
            email: currentUser.email,
            displayName: currentUser.displayName,
            photoURL: currentUser.photoURL,
            isPremium: false,
            createdAt: new Date()
          });
        }

        // Listen for profile changes (like premium status)
        const unsubProfile = onSnapshot(userRef, (doc) => {
          if (doc.exists()) {
            setUserProfile(doc.data());
          }
        });

        return () => unsubProfile();
      } else {
        setUserProfile(null);
      }
    });

    return () => unsubscribe();
  }, []);

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-background text-gray-100 font-sans selection:bg-primary/30">
        {/* Header */}
        <header className="border-b border-white/10 bg-surface/50 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-emerald-700 rounded-lg flex items-center justify-center shadow-lg shadow-primary/20">
                <Zap className="w-5 h-5 text-white fill-white" />
              </div>
              <h1 className="text-xl font-bold tracking-tight text-white">Tecrypto <span className="text-primary">NDX</span> Tracker</h1>
            </div>
            
            <div className="flex items-center gap-4">
               {user ? (
                 <div className="flex items-center gap-4">
                   {!userProfile?.isPremium && (
                     <button 
                       onClick={() => setIsPricingOpen(true)}
                       className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-primary to-emerald-600 hover:from-emerald-500 hover:to-primary text-white rounded-xl font-bold text-sm transition-all shadow-lg shadow-primary/30 active:scale-95 group"
                     >
                       <Zap className="w-4 h-4 fill-white group-hover:animate-pulse" />
                       Upgrade to Premium
                     </button>
                   )}
                   {userProfile?.isPremium && (
                     <div className="flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/30 rounded-xl">
                       <Star className="w-4 h-4 text-primary fill-primary" />
                       <span className="text-xs font-bold text-primary uppercase tracking-wider">Premium Member</span>
                     </div>
                   )}
                   <div className="flex items-center gap-3 pl-4 border-l border-white/10">
                     {user.photoURL ? (
                       <img src={user.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-primary/50" />
                     ) : (
                       <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center border border-white/10">
                         <UserIcon className="w-4 h-4 text-zinc-400" />
                       </div>
                     )}
                     <button 
                       onClick={logout}
                       className="p-2 hover:bg-white/5 rounded-lg transition-colors text-zinc-400 hover:text-white"
                       title="Logout"
                     >
                       <LogOut className="w-5 h-5" />
                     </button>
                   </div>
                 </div>
               ) : (
                 <button 
                   onClick={signInWithGoogle}
                   className="flex items-center gap-2 px-5 py-2.5 bg-white text-black hover:bg-zinc-200 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-95"
                 >
                   <LogIn className="w-4 h-4" />
                   Sign in with Google
                 </button>
               )}
               
               <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10">
                 <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                 <span className="text-xs font-medium text-gray-300">Gemini AI Active</span>
               </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 py-8 space-y-6">
          {!user ? (
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-12 text-center max-w-2xl mx-auto">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Master the Nasdaq 100</h2>
              <p className="text-zinc-400 mb-8 leading-relaxed">
                Log in to access real-time ICT analysis, session timers, and your personal trade journal. 
                Keep track of your progress and refine your market narrative with AI-powered insights.
              </p>
              <button 
                onClick={signInWithGoogle}
                className="px-8 py-4 bg-primary hover:bg-emerald-600 text-white rounded-xl font-bold text-lg transition-all shadow-xl shadow-primary/20 active:scale-95"
              >
                Get Started Now
              </button>
            </div>
          ) : (
            <>
              {/* Top Row: Narrative & Clock */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                  <KillZoneClock />
                </div>
                <div className="lg:col-span-2">
                  <MarketNarrative />
                </div>
              </div>

              {/* Middle Row: Live Chart (Full Width) */}
              <div>
                <LiveChart />
              </div>

              {/* Bottom Row: Analyzer & Journal */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ChartAnalyzer onAnalysisComplete={setLatestAnalysis} isPremium={userProfile?.isPremium} />
                <div className="h-[600px] lg:h-auto">
                  <TradeJournal latestAnalysis={latestAnalysis} />
                </div>
              </div>

              {/* Visualizer Row */}
              <div className="max-w-4xl mx-auto w-full">
                <IctImageGenerator isPremium={userProfile?.isPremium} />
              </div>
            </>
          )}
        </main>

        <footer className="border-t border-white/10 mt-12 py-8 bg-surface/30">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-4 opacity-30">
              <Zap className="w-4 h-4 fill-white" />
              <span className="text-sm font-bold tracking-tighter uppercase">Tecrypto</span>
            </div>
            <p className="text-sm text-gray-500 italic">
              "If you don't see the liquidity, you are the liquidity."
            </p>
            <div className="flex flex-wrap items-center justify-center gap-6 mt-6 text-xs text-gray-500">
              <a href="tel:+254727993501" className="flex items-center gap-2 hover:text-primary transition-colors">
                <Phone className="w-3.5 h-3.5" />
                +254727993501
              </a>
              <a href="mailto:info@tetu.live" className="flex items-center gap-2 hover:text-primary transition-colors">
                <Mail className="w-3.5 h-3.5" />
                info@tetu.live
              </a>
              <a href="https://www.tetu.live" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors">
                <Globe className="w-3.5 h-3.5" />
                www.tetu.live
              </a>
            </div>
            <p className="text-xs text-gray-600 mt-6">
              &copy; {new Date().getFullYear()} Tecrypto. Built with React, Tailwind & Gemini 3.1 Pro. Not financial advice.
            </p>
          </div>
        </footer>

        <Pricing isOpen={isPricingOpen} onClose={() => setIsPricingOpen(false)} />
      </div>
    </ErrorBoundary>
  );
};

export default App;