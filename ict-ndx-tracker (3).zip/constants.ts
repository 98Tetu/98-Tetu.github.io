import { ICTSession, ICTConcept } from './types';

// Assuming EST based times (UTC-5/UTC-4). 
// For simplicity in this demo, we will treat these as "User Local" targets or convert dynamically.
// Here we define them in generic "trading hours" relative to NY time (EST).
// We will handle timezone logic in the component.
export const ICT_SESSIONS: ICTSession[] = [
  {
    name: "Asian Range",
    startLocal: "18:00",
    endLocal: "00:00",
    description: "Accumulation phase. Usually sets the initial range.",
    type: 'Asian'
  },
  {
    name: "London Open (Judas Swing)",
    startLocal: "02:00",
    endLocal: "05:00",
    description: "Often creates the high or low of the day.",
    type: 'London'
  },
  {
    name: "NY AM Session",
    startLocal: "09:30",
    endLocal: "11:00",
    description: "High volatility. Look for reversals or continuation.",
    type: 'NewYork'
  },
  {
    name: "Lunch Macro",
    startLocal: "12:00",
    endLocal: "13:00",
    description: "Price often consolidates or seeks liquidity.",
    type: 'NewYork'
  },
  {
    name: "NY PM Session",
    startLocal: "13:30",
    endLocal: "16:00",
    description: "End of day run on liquidity.",
    type: 'Close'
  }
];

export const AVAILABLE_CONCEPTS = [
  ICTConcept.FVG,
  ICTConcept.OB,
  ICTConcept.Breaker,
  ICTConcept.LiquiditySweep,
  ICTConcept.MSS,
  ICTConcept.OTE
];
